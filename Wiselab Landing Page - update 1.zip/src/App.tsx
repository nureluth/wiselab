import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import { LanguageProvider } from './contexts/LanguageContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Homepage from './components/Homepage';
import ServicesPage from './components/ServicesPage';
import PortfolioPage from './components/PortfolioPage';
import PortfolioDetail from './components/PortfolioDetail';
import ContactPage from './components/ContactPage';
import JoinFreelancePage from './components/JoinFreelancePage';

// Sample Websites
import FashionStore from './components/samples/FashionStore';
import FitnessStudio from './components/samples/FitnessStudio';
import TravelAgency from './components/samples/TravelAgency';
import CoffeeShop from './components/samples/CoffeeShop';
import ArchitectStudio from './components/samples/ArchitectStudio';
import DigitalAgency from './components/samples/DigitalAgency';
import OnlineCourse from './components/samples/OnlineCourse';
import FoodDelivery from './components/samples/FoodDelivery';
import MusicStudio from './components/samples/MusicStudio';
import SaasLanding from './components/samples/SaasLanding';
import RealEstate from './components/samples/RealEstate';
import CreativePortfolio from './components/samples/CreativePortfolio';
import EventManagement from './components/samples/EventManagement';
import PhotographyStudio from './components/samples/PhotographyStudio';

function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

export default function App() {
  return (
    <Router>
      <LanguageProvider>
        <div className="min-h-screen bg-[#0A192F] text-white">
          <ScrollToTop />
          <Navbar />
          <Routes>
            <Route path="/" element={<Homepage />} />
            <Route path="/services" element={<ServicesPage />} />
            <Route path="/portfolio" element={<PortfolioPage />} />
            <Route path="/portfolio/:id" element={<PortfolioDetail />} />
            <Route path="/join-freelance" element={<JoinFreelancePage />} />
            <Route path="/contact" element={<ContactPage />} />
            
            {/* Sample Websites */}
            <Route path="/portfolio/fashion-store" element={<FashionStore />} />
            <Route path="/portfolio/fitness-studio" element={<FitnessStudio />} />
            <Route path="/portfolio/travel-agency" element={<TravelAgency />} />
            <Route path="/portfolio/coffee-shop" element={<CoffeeShop />} />
            <Route path="/portfolio/architect-studio" element={<ArchitectStudio />} />
            <Route path="/portfolio/digital-agency" element={<DigitalAgency />} />
            <Route path="/portfolio/online-course" element={<OnlineCourse />} />
            <Route path="/portfolio/food-delivery" element={<FoodDelivery />} />
            <Route path="/portfolio/music-studio" element={<MusicStudio />} />
            <Route path="/portfolio/saas-landing" element={<SaasLanding />} />
            <Route path="/portfolio/real-estate" element={<RealEstate />} />
            <Route path="/portfolio/creative-portfolio" element={<CreativePortfolio />} />
            <Route path="/portfolio/event-management" element={<EventManagement />} />
            <Route path="/portfolio/photography-studio" element={<PhotographyStudio />} />
          </Routes>
          <Footer />
        </div>
      </LanguageProvider>
    </Router>
  );
}