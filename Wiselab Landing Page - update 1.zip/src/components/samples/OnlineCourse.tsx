import { motion } from 'motion/react';
import { BookOpen, Users, Award, PlayCircle, Star, Clock, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export default function OnlineCourse() {
  const { t } = useLanguage();
  const courses = [
    { id: 1, title: 'Web Development Bootcamp', students: 12000, rating: 4.9, price: 89, image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=500' },
    { id: 2, title: 'UI/UX Design Mastery', students: 8500, rating: 4.8, price: 79, image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=500' },
    { id: 3, title: 'Digital Marketing Pro', students: 15000, rating: 4.9, price: 69, image: 'https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a?w=500' },
  ];

  return (
    <div className="min-h-screen bg-indigo-950">
      {/* Back Button */}
      <Link to="/portfolio">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed top-24 left-4 z-50 bg-indigo-500 text-white px-4 py-2 rounded-full shadow-lg hover:bg-indigo-600 transition-all flex items-center gap-2 group"
        >
          <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
          <span className="hidden sm:inline">{t('common.backToProducts')}</span>
        </motion.button>
      </Link>

      <nav className="bg-indigo-950/90 backdrop-blur-sm border-b border-indigo-800 sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <BookOpen className="text-indigo-400" size={28} />
              <h2 className="text-white">SkillUp</h2>
            </div>
            <div className="hidden md:flex gap-6 text-gray-300">
              <a href="#" className="hover:text-indigo-400">Courses</a>
              <a href="#" className="hover:text-indigo-400">Pricing</a>
              <a href="#" className="hover:text-indigo-400">About</a>
            </div>
            <Button className="bg-indigo-500 text-white hover:bg-indigo-600">Sign Up Free</Button>
          </div>
        </div>
      </nav>

      <section className="py-24 bg-gradient-to-b from-indigo-950 to-indigo-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <Badge className="mb-4 bg-indigo-500 text-white">Trusted by 50,000+ Students</Badge>
              <h1 className="text-white mb-6">
                Learn Skills That
                <span className="text-indigo-400"> Launch Careers</span>
              </h1>
              <p className="text-indigo-200 text-xl mb-8">
                Master in-demand skills with expert-led courses. Start learning today and transform your future.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button className="bg-indigo-500 text-white hover:bg-indigo-600 px-8 py-6">
                  Browse Courses
                </Button>
                <Button variant="outline" className="border-2 border-indigo-500 text-indigo-400 hover:bg-indigo-500 hover:text-white px-8 py-6">
                  <PlayCircle className="mr-2" size={20} />
                  Watch Demo
                </Button>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1610484826967-09c5720778c7?w=800"
                alt="Learning"
                className="rounded-lg shadow-2xl"
              />
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-indigo-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-white mb-4">Popular Courses</h2>
            <p className="text-indigo-200 text-lg">Join thousands learning these top-rated courses</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {courses.map((course, index) => (
              <motion.div
                key={course.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="bg-indigo-800 border-indigo-700 overflow-hidden hover:border-indigo-500 transition-all">
                  <div className="relative h-48">
                    <ImageWithFallback 
                      src={course.image}
                      alt={course.title}
                      className="w-full h-full object-cover"
                    />
                    <Badge className="absolute top-4 right-4 bg-yellow-500 text-yellow-900">
                      Bestseller
                    </Badge>
                  </div>
                  <CardContent className="p-6">
                    <h3 className="text-white mb-3">{course.title}</h3>
                    <div className="flex items-center gap-4 mb-4 text-indigo-200 text-sm">
                      <span className="flex items-center gap-1">
                        <Star size={16} className="fill-yellow-400 text-yellow-400" />
                        {course.rating}
                      </span>
                      <span className="flex items-center gap-1">
                        <Users size={16} />
                        {course.students.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-2xl text-white">${course.price}</span>
                      <Button className="bg-indigo-500 hover:bg-indigo-600 text-white">Enroll Now</Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-indigo-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: Award, title: 'Expert Instructors', desc: 'Learn from industry professionals' },
              { icon: Clock, title: 'Lifetime Access', desc: 'Learn at your own pace' },
              { icon: Users, title: 'Community', desc: 'Join 50,000+ learners' },
            ].map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-16 h-16 bg-indigo-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="text-indigo-400" size={28} />
                </div>
                <h3 className="text-white mb-2">{feature.title}</h3>
                <p className="text-indigo-300">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-r from-indigo-600 to-purple-600">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-white mb-6">Start Learning Today</h2>
          <p className="text-indigo-100 text-lg mb-8 max-w-2xl mx-auto">
            Join our community and get access to hundreds of courses. First 7 days free!
          </p>
          <Button className="bg-white text-indigo-600 hover:bg-indigo-50 px-8 py-6 text-lg">
            Start Free Trial
          </Button>
        </div>
      </section>
    </div>
  );
}