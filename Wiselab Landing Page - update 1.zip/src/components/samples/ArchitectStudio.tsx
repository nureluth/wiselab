import { motion } from 'motion/react';
import { Ruler, Award, Users, ArrowRight, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export default function ArchitectStudio() {
  const { t } = useLanguage();
  const projects = [
    { id: 1, title: 'Modern Villa', category: 'Residential', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=600' },
    { id: 2, title: 'Tech Campus', category: 'Commercial', image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600' },
    { id: 3, title: 'Urban Loft', category: 'Interior', image: 'https://images.unsplash.com/photo-1600210492493-0946911123ea?w=600' },
    { id: 4, title: 'Sky Tower', category: 'Commercial', image: 'https://images.unsplash.com/photo-1519662978799-2f05096d3636?w=600' },
  ];

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-50">
      {/* Back Button */}
      <Link to="/portfolio">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed top-24 left-4 z-50 bg-neutral-100 text-neutral-950 px-4 py-2 rounded-full shadow-lg hover:bg-neutral-200 transition-all flex items-center gap-2 group"
        >
          <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
          <span className="hidden sm:inline">{t('common.backToProducts')}</span>
        </motion.button>
      </Link>

      {/* Navigation */}
      <nav className="bg-neutral-950/90 backdrop-blur-sm border-b border-neutral-800 sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <h2 className="text-neutral-50">ARCVISION</h2>
            <div className="hidden md:flex gap-8">
              <a href="#work" className="text-neutral-400 hover:text-neutral-50 transition-colors">Work</a>
              <a href="#about" className="text-neutral-400 hover:text-neutral-50 transition-colors">About</a>
              <a href="#contact" className="text-neutral-400 hover:text-neutral-50 transition-colors">Contact</a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative h-screen">
        <div className="absolute inset-0">
          <ImageWithFallback 
            src="https://images.unsplash.com/photo-1519662978799-2f05096d3636?w=1920"
            alt="Architecture"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-neutral-950/60" />
        </div>
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="max-w-3xl"
          >
            <h1 className="text-neutral-50 mb-6 text-7xl">
              Designing
              <br />
              Tomorrow's
              <br />
              Spaces
            </h1>
            <p className="text-neutral-300 text-xl mb-8 max-w-xl">
              Award-winning architecture studio creating iconic structures that inspire and endure.
            </p>
            <Button className="bg-neutral-50 text-neutral-950 hover:bg-neutral-200 px-8 py-6 group">
              Explore Projects
              <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-24 border-y border-neutral-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { value: '150+', label: 'Projects Completed' },
              { value: '25+', label: 'Awards Won' },
              { value: '30+', label: 'Team Members' },
              { value: '15', label: 'Years Experience' },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-5xl mb-2 text-neutral-50">{stat.value}</div>
                <div className="text-neutral-400">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects */}
      <section id="work" className="py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-16">
            <h2 className="text-neutral-50 mb-4">Featured Work</h2>
            <p className="text-neutral-400 text-lg max-w-2xl">
              A selection of our most inspiring projects that push the boundaries of design.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {projects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                className="group cursor-pointer"
              >
                <div className="relative h-96 overflow-hidden bg-neutral-900">
                  <ImageWithFallback 
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-neutral-950/0 group-hover:bg-neutral-950/40 transition-colors duration-500" />
                </div>
                <div className="mt-6">
                  <p className="text-neutral-500 text-sm mb-2">{project.category}</p>
                  <h3 className="text-neutral-50 text-2xl">{project.title}</h3>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-24 bg-neutral-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { icon: Ruler, title: 'Architecture', desc: 'Innovative design solutions for residential and commercial spaces' },
              { icon: Users, title: 'Planning', desc: 'Strategic planning and urban design for sustainable development' },
              { icon: Award, title: 'Interior Design', desc: 'Thoughtful interiors that enhance the human experience' },
            ].map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <service.icon className="text-neutral-50 mb-6" size={40} />
                <h3 className="text-neutral-50 mb-4">{service.title}</h3>
                <p className="text-neutral-400">{service.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 border-t border-neutral-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-neutral-50 mb-6">Let's Create Something Extraordinary</h2>
            <p className="text-neutral-400 text-lg mb-8">
              Ready to bring your vision to life? Get in touch with our team.
            </p>
            <Button className="bg-neutral-50 text-neutral-950 hover:bg-neutral-200 px-8 py-6">
              Start a Project
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-neutral-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div>
              <h3 className="text-neutral-50 mb-2">ARCVISION</h3>
              <p className="text-neutral-500">© 2024 All rights reserved</p>
            </div>
            <div className="flex gap-6 text-neutral-500">
              <a href="#" className="hover:text-neutral-50 transition-colors">Instagram</a>
              <a href="#" className="hover:text-neutral-50 transition-colors">Behance</a>
              <a href="#" className="hover:text-neutral-50 transition-colors">LinkedIn</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}