import { motion } from 'motion/react';
import { UtensilsCrossed, Clock, Truck, MapPin, Search, Star, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export default function FoodDelivery() {
  const { t } = useLanguage();
  const restaurants = [
    { id: 1, name: 'Burger House', cuisine: 'American', rating: 4.8, delivery: '25-35 min', image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400' },
    { id: 2, name: 'Sushi Express', cuisine: 'Japanese', rating: 4.9, delivery: '30-40 min', image: 'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=400' },
    { id: 3, name: 'Pizza Italia', cuisine: 'Italian', rating: 4.7, delivery: '20-30 min', image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400' },
  ];

  return (
    <div className="min-h-screen bg-rose-50">
      {/* Back Button */}
      <Link to="/portfolio">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed top-24 left-4 z-50 bg-rose-600 text-white px-4 py-2 rounded-full shadow-lg hover:bg-rose-700 transition-all flex items-center gap-2 group"
        >
          <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
          <span className="hidden sm:inline">{t('common.backToProducts')}</span>
        </motion.button>
      </Link>

      <nav className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <UtensilsCrossed className="text-rose-600" size={28} />
              <h2 className="text-rose-600">FoodHub</h2>
            </div>
            <div className="hidden md:flex gap-6">
              <a href="#" className="text-gray-700 hover:text-rose-600">Restaurants</a>
              <a href="#" className="text-gray-700 hover:text-rose-600">Offers</a>
              <a href="#" className="text-gray-700 hover:text-rose-600">Track Order</a>
            </div>
            <Button className="bg-rose-600 text-white hover:bg-rose-700">Sign In</Button>
          </div>
        </div>
      </nav>

      <section className="py-20 bg-gradient-to-r from-rose-500 to-orange-500">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center text-white"
          >
            <h1 className="mb-6">
              Hungry? Order Now!
            </h1>
            <p className="text-xl mb-8 max-w-2xl mx-auto text-rose-50">
              Get your favorite food delivered hot and fresh to your doorstep in minutes.
            </p>
            <Card className="max-w-2xl mx-auto bg-white p-6">
              <div className="flex gap-2">
                <div className="flex-1 flex items-center gap-2 px-4 border border-gray-300 rounded-lg">
                  <MapPin size={20} className="text-gray-400" />
                  <input 
                    type="text" 
                    placeholder="Enter your address" 
                    className="flex-1 outline-none py-3"
                  />
                </div>
                <Button className="bg-rose-600 hover:bg-rose-700 text-white px-8">
                  <Search size={20} />
                </Button>
              </div>
            </Card>
          </motion.div>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {[
              { icon: Clock, title: 'Fast Delivery', desc: 'Get food in 30 minutes' },
              { icon: Truck, title: 'Free Delivery', desc: 'On orders over $20' },
              { icon: Star, title: 'Top Rated', desc: '1000+ restaurants' },
            ].map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="text-rose-600" size={28} />
                </div>
                <h3 className="text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.desc}</p>
              </motion.div>
            ))}
          </div>

          <div className="mb-8">
            <h2 className="text-gray-900 mb-4">Popular Restaurants</h2>
            <p className="text-gray-600 text-lg">Discover the best food near you</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {restaurants.map((restaurant, index) => (
              <motion.div
                key={restaurant.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="overflow-hidden hover:shadow-xl transition-shadow group cursor-pointer">
                  <div className="relative h-48">
                    <ImageWithFallback 
                      src={restaurant.image}
                      alt={restaurant.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <Badge className="absolute top-4 left-4 bg-white text-gray-900">
                      <Star size={12} className="inline mr-1 fill-yellow-400 text-yellow-400" />
                      {restaurant.rating}
                    </Badge>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="text-gray-900 mb-1">{restaurant.name}</h3>
                    <p className="text-gray-600 text-sm mb-2">{restaurant.cuisine}</p>
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <span className="flex items-center gap-1">
                        <Clock size={14} />
                        {restaurant.delivery}
                      </span>
                      <span className="text-rose-600">Free delivery</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-rose-600">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <h2 className="mb-6">Download the App</h2>
          <p className="text-xl text-rose-100 mb-8 max-w-2xl mx-auto">
            Get exclusive deals and faster ordering with our mobile app
          </p>
          <div className="flex justify-center gap-4">
            <Button className="bg-white text-rose-600 hover:bg-rose-50 px-8 py-6">
              App Store
            </Button>
            <Button className="bg-white text-rose-600 hover:bg-rose-50 px-8 py-6">
              Play Store
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}