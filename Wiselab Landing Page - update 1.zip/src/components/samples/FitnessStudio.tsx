import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Dumbbell, Users, Calendar, Trophy, Star, Play, MapPin, Phone, Mail } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export default function FitnessStudio() {
  const { t } = useLanguage();

  const programs = [
    { id: 1, name: 'Strength Training', duration: '45 min', level: 'All Levels', image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=500' },
    { id: 2, name: 'Yoga & Meditation', duration: '60 min', level: 'Beginner', image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=500' },
    { id: 3, name: 'HIIT Cardio', duration: '30 min', level: 'Advanced', image: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=500' },
    { id: 4, name: 'Pilates', duration: '50 min', level: 'Intermediate', image: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=500' },
  ];

  const trainers = [
    { name: 'Sarah Johnson', specialty: 'Personal Trainer', image: 'https://images.unsplash.com/photo-1594381898411-846e7d193883?w=400' },
    { name: 'Mike Chen', specialty: 'Yoga Instructor', image: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=400' },
    { name: 'Emma Davis', specialty: 'Nutrition Coach', image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400' },
  ];

  return (
    <div className="min-h-screen bg-zinc-900">
      {/* Back to Portfolio Button */}
      <Link to="/portfolio">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed top-24 left-4 z-50 bg-orange-500 text-white px-4 py-2 rounded-full shadow-lg hover:bg-orange-600 transition-all flex items-center gap-2 group"
        >
          <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
          <span className="hidden sm:inline">{t('common.backToProducts')}</span>
        </motion.button>
      </Link>

      {/* Navigation */}
      <nav className="bg-zinc-900/95 backdrop-blur-sm border-b border-orange-500/20 sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Dumbbell className="text-orange-500" size={28} />
              <h2 className="text-white">FITZONE</h2>
            </div>
            <div className="hidden md:flex gap-6">
              <a href="#programs" className="text-gray-300 hover:text-orange-500 transition-colors">Programs</a>
              <a href="#schedule" className="text-gray-300 hover:text-orange-500 transition-colors">Schedule</a>
              <a href="#trainers" className="text-gray-300 hover:text-orange-500 transition-colors">Trainers</a>
              <a href="#pricing" className="text-gray-300 hover:text-orange-500 transition-colors">Pricing</a>
            </div>
            <Button className="bg-orange-500 text-white hover:bg-orange-600">Join Now</Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen">
        <div className="absolute inset-0">
          <ImageWithFallback 
            src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1920"
            alt="Fitness"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-zinc-900 via-zinc-900/80 to-transparent" />
        </div>
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center relative z-10">
          <div className="max-w-2xl">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-white mb-6">
                Transform Your Body,
                <span className="text-orange-500"> Elevate Your Life</span>
              </h1>
              <p className="text-gray-300 text-xl mb-8">
                Join the ultimate fitness community. Expert trainers, state-of-the-art equipment, and personalized programs.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button className="bg-orange-500 text-white hover:bg-orange-600 px-8 py-6">
                  Start Free Trial
                </Button>
                <Button variant="outline" className="border-2 border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white px-8 py-6">
                  View Schedule
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 bg-orange-500">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { label: 'Members', value: '2,500+' },
              { label: 'Classes/Week', value: '100+' },
              { label: 'Expert Trainers', value: '25+' },
              { label: 'Success Stories', value: '1,000+' },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <h2 className="text-white mb-2">{stat.value}</h2>
                <p className="text-orange-100">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Programs */}
      <section id="programs" className="py-20 bg-zinc-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-white mb-4">Our Programs</h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Choose from our diverse range of programs designed to meet your fitness goals
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {programs.map((program, index) => (
              <motion.div
                key={program.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="bg-zinc-800 border-zinc-700 overflow-hidden group hover:border-orange-500 transition-all">
                  <div className="relative h-48 overflow-hidden">
                    <ImageWithFallback 
                      src={program.image}
                      alt={program.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 to-transparent" />
                  </div>
                  <CardContent className="p-6">
                    <h3 className="text-white mb-2">{program.name}</h3>
                    <div className="flex items-center gap-4 text-gray-400 text-sm">
                      <span className="flex items-center gap-1">
                        <Play size={16} />
                        {program.duration}
                      </span>
                      <span className="flex items-center gap-1">
                        <Star size={16} />
                        {program.level}
                      </span>
                    </div>
                    <Button className="w-full mt-4 bg-orange-500 hover:bg-orange-600 text-white">
                      Book Class
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Trainers */}
      <section id="trainers" className="py-20 bg-zinc-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-white mb-4">Meet Our Trainers</h2>
            <p className="text-gray-400 text-lg">Certified professionals dedicated to your success</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {trainers.map((trainer, index) => (
              <motion.div
                key={trainer.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="bg-zinc-900 border-zinc-700 overflow-hidden group hover:border-orange-500 transition-all">
                  <div className="relative h-80 overflow-hidden">
                    <ImageWithFallback 
                      src={trainer.image}
                      alt={trainer.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-6 text-center">
                    <h3 className="text-white mb-2">{trainer.name}</h3>
                    <p className="text-orange-500 mb-4">{trainer.specialty}</p>
                    <Button variant="outline" className="border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white">
                      Book Session
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-20 bg-zinc-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-white mb-4">Membership Plans</h2>
            <p className="text-gray-400 text-lg">Choose the perfect plan for your fitness journey</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              { name: 'Basic', price: '29', features: ['Access to gym', '10 classes/month', 'Locker access'] },
              { name: 'Premium', price: '59', features: ['Unlimited classes', 'Personal trainer session', 'Nutrition guidance', 'Free parking'], popular: true },
              { name: 'Elite', price: '99', features: ['All Premium features', '4 PT sessions/month', 'Spa access', 'Guest passes'] },
            ].map((plan) => (
              <Card key={plan.name} className={`bg-zinc-800 border-zinc-700 relative ${plan.popular ? 'border-orange-500 border-2' : ''}`}>
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-orange-500 text-white px-4 py-1 rounded-full text-sm">
                    Most Popular
                  </div>
                )}
                <CardContent className="p-8">
                  <h3 className="text-white mb-2">{plan.name}</h3>
                  <div className="mb-6">
                    <span className="text-5xl text-white">${plan.price}</span>
                    <span className="text-gray-400">/month</span>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature) => (
                      <li key={feature} className="text-gray-400 flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-orange-500 rounded-full" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button className={`w-full ${plan.popular ? 'bg-orange-500 hover:bg-orange-600' : 'bg-zinc-700 hover:bg-zinc-600'} text-white`}>
                    Get Started
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-20 bg-gradient-to-r from-orange-500 to-orange-600">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-white mb-6">Ready to Start Your Journey?</h2>
          <p className="text-orange-100 text-lg mb-8 max-w-2xl mx-auto">
            Join FITZONE today and get your first week free. No commitment required.
          </p>
          <Button className="bg-white text-orange-500 hover:bg-orange-50 px-8 py-6 text-lg">
            Claim Free Week
          </Button>
          <div className="flex flex-wrap justify-center gap-8 mt-12 text-white">
            <div className="flex items-center gap-2">
              <MapPin size={20} />
              <span>123 Fitness St, New York</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone size={20} />
              <span>(555) 123-4567</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail size={20} />
              <span>hello@fitzone.com</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}