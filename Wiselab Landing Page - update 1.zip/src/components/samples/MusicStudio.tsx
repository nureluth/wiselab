import { motion } from 'motion/react';
import { Music, Mic, Headphones, Play, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';

export default function MusicStudio() {
  const { t } = useLanguage();
  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Back Button */}
      <Link to="/portfolio">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed top-24 left-4 z-50 bg-violet-500 text-white px-4 py-2 rounded-full shadow-lg hover:bg-violet-600 transition-all flex items-center gap-2 group"
        >
          <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
          <span className="hidden sm:inline">{t('common.backToProducts')}</span>
        </motion.button>
      </Link>

      <nav className="bg-slate-950/80 backdrop-blur-sm border-b border-slate-800 sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Music className="text-violet-500" size={28} />
              <h2>SoundLab</h2>
            </div>
            <div className="hidden md:flex gap-6 text-slate-400">
              <a href="#" className="hover:text-violet-500">Studios</a>
              <a href="#" className="hover:text-violet-500">Services</a>
              <a href="#" className="hover:text-violet-500">Portfolio</a>
            </div>
            <Button className="bg-violet-600 hover:bg-violet-700 text-white">Book Session</Button>
          </div>
        </div>
      </nav>

      <section className="py-32 bg-gradient-to-b from-violet-950/50 to-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="mb-6 text-6xl">
              Professional
              <br />
              <span className="text-violet-500">Recording Studio</span>
            </h1>
            <p className="text-slate-400 text-xl mb-12 max-w-2xl mx-auto">
              State-of-the-art equipment, expert engineers, and the perfect space to bring your music to life.
            </p>
            <Button className="bg-violet-600 hover:bg-violet-700 text-white px-8 py-6 text-lg">
              <Play className="mr-2" size={20} />
              View Demo Reel
            </Button>
          </motion.div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: Mic, title: 'Recording', desc: 'Professional multi-track recording' },
              { icon: Headphones, title: 'Mixing & Mastering', desc: 'Industry-standard sound quality' },
              { icon: Music, title: 'Production', desc: 'Full music production services' },
            ].map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="bg-slate-900 border-slate-800 hover:border-violet-500 transition-all">
                  <CardContent className="p-8 text-center">
                    <div className="w-16 h-16 bg-violet-600/20 rounded-full flex items-center justify-center mx-auto mb-4">
                      <service.icon className="text-violet-500" size={28} />
                    </div>
                    <h3 className="mb-3">{service.title}</h3>
                    <p className="text-slate-400">{service.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-violet-600">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="mb-6">Ready to Record?</h2>
          <p className="text-violet-100 text-lg mb-8 max-w-2xl mx-auto">
            Book your session today and experience professional recording at its finest.
          </p>
          <Button className="bg-white text-violet-600 hover:bg-violet-50 px-8 py-6">
            Check Availability
          </Button>
        </div>
      </section>
    </div>
  );
}