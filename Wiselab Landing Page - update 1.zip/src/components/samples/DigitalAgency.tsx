import { motion } from 'motion/react';
import { Zap, TrendingUp, Target, Sparkles, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';

export default function DigitalAgency() {
  const { t } = useLanguage();
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-orange-400">
      {/* Back Button */}
      <Link to="/portfolio">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed top-24 left-4 z-50 bg-white text-purple-600 px-4 py-2 rounded-full shadow-lg hover:bg-purple-50 transition-all flex items-center gap-2 group"
        >
          <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
          <span className="hidden sm:inline">{t('common.backToProducts')}</span>
        </motion.button>
      </Link>

      <nav className="bg-white/10 backdrop-blur-md sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <h2 className="text-white">PIXEL</h2>
            <div className="hidden md:flex gap-6 text-white">
              <a href="#services" className="hover:text-purple-200">Services</a>
              <a href="#work" className="hover:text-purple-200">Work</a>
              <a href="#contact" className="hover:text-purple-200">Contact</a>
            </div>
            <Button className="bg-white text-purple-600 hover:bg-purple-50">Get Started</Button>
          </div>
        </div>
      </nav>

      <section className="py-32">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-white mb-6 text-7xl">
              Digital Magic
              <br />
              That Converts
            </h1>
            <p className="text-white/90 text-xl mb-8 max-w-2xl mx-auto">
              We create stunning digital experiences that drive results and make your brand unforgettable.
            </p>
            <Button className="bg-white text-purple-600 hover:bg-purple-50 px-8 py-6 text-lg">
              Let's Talk
            </Button>
          </motion.div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-gray-900 mb-4">What We Do</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { icon: Sparkles, title: 'Brand Strategy', desc: 'Crafting unique brand identities' },
              { icon: Zap, title: 'Web Design', desc: 'Beautiful, conversion-focused designs' },
              { icon: TrendingUp, title: 'Marketing', desc: 'Data-driven digital campaigns' },
              { icon: Target, title: 'SEO', desc: 'Dominate search rankings' },
            ].map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                  <CardContent className="p-8 text-center">
                    <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <service.icon className="text-white" size={28} />
                    </div>
                    <h3 className="text-gray-900 mb-2">{service.title}</h3>
                    <p className="text-gray-600">{service.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-900 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="mb-4">Ready to Grow?</h2>
          <p className="text-gray-300 text-lg mb-8 max-w-2xl mx-auto">
            Let's create something amazing together. Get your free consultation today.
          </p>
          <Button className="bg-gradient-to-r from-purple-600 to-pink-500 text-white hover:opacity-90 px-8 py-6">
            Book Free Consultation
          </Button>
        </div>
      </section>
    </div>
  );
}