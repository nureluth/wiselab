import { motion } from 'motion/react';
import { Camera, Award, Users, Instagram, ArrowLeft, Mail } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export default function PhotographyStudio() {
  const { t } = useLanguage();
  const gallery = [
    { id: 1, category: 'Wedding', image: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=600' },
    { id: 2, category: 'Portrait', image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=600' },
    { id: 3, category: 'Nature', image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600' },
    { id: 4, category: 'Fashion', image: 'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=600' },
    { id: 5, category: 'Architecture', image: 'https://images.unsplash.com/photo-1487958449943-2429e8be8625?w=600' },
    { id: 6, category: 'Commercial', image: 'https://images.unsplash.com/photo-1556740749-887f6717d7e4?w=600' },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Back Button */}
      <Link to="/portfolio">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed top-24 left-4 z-50 bg-gray-900 text-white px-4 py-2 rounded-full shadow-lg hover:bg-gray-800 transition-all flex items-center gap-2 group"
        >
          <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
          <span className="hidden sm:inline">{t('common.backToProducts')}</span>
        </motion.button>
      </Link>

      <nav className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center gap-2">
              <Camera className="text-gray-900" size={28} />
              <h2 className="text-gray-900 text-2xl">LENS</h2>
            </div>
            <div className="hidden md:flex gap-8 text-gray-600">
              <a href="#portfolio" className="hover:text-gray-900 transition-colors">Portfolio</a>
              <a href="#services" className="hover:text-gray-900 transition-colors">Services</a>
              <a href="#about" className="hover:text-gray-900 transition-colors">About</a>
              <a href="#contact" className="hover:text-gray-900 transition-colors">Contact</a>
            </div>
            <Button className="bg-gray-900 text-white hover:bg-gray-800">Book Session</Button>
          </div>
        </div>
      </nav>

      <section className="relative h-screen">
        <div className="absolute inset-0">
          <ImageWithFallback 
            src="https://images.unsplash.com/photo-1452587925148-ce544e77e70d?w=1920"
            alt="Photography"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/40" />
        </div>
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="max-w-2xl text-white"
          >
            <h1 className="text-7xl mb-8 leading-tight">
              Capturing
              <br />
              Life's Beautiful
              <br />
              Moments
            </h1>
            <p className="text-xl text-white/90 mb-12 max-w-xl">
              Professional photography services for weddings, portraits, events, and commercial projects.
            </p>
            <Button className="bg-white text-gray-900 hover:bg-gray-100 px-8 py-6 text-lg">
              View Portfolio
            </Button>
          </motion.div>
        </div>
      </section>

      <section id="portfolio" className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-gray-900 mb-4">Portfolio</h2>
            <p className="text-gray-600 text-lg">A curated selection of my work</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {gallery.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="group relative aspect-square overflow-hidden cursor-pointer"
              >
                <ImageWithFallback 
                  src={item.image}
                  alt={item.category}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/60 transition-colors flex items-center justify-center">
                  <p className="text-white text-xl opacity-0 group-hover:opacity-100 transition-opacity">
                    {item.category}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section id="services" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { icon: Camera, title: 'Wedding Photography', desc: 'Capture your special day with timeless elegance' },
              { icon: Award, title: 'Commercial Work', desc: 'Product and commercial photography for brands' },
            ].map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-16 h-16 bg-gray-900 rounded-full flex items-center justify-center mx-auto mb-6">
                  <service.icon className="text-white" size={28} />
                </div>
                <h3 className="text-gray-900 mb-3">{service.title}</h3>
                <p className="text-gray-600">{service.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Mail className="mx-auto mb-6 text-gray-900" size={48} />
          <h2 className="text-gray-900 mb-6">Let's Create Together</h2>
          <p className="text-gray-600 text-lg mb-8 max-w-2xl mx-auto">
            Ready to book a session? Get in touch and let's discuss your vision.
          </p>
          <Button className="bg-gray-900 text-white hover:bg-gray-800 px-8 py-6 text-lg">
            Contact Me
          </Button>
        </div>
      </section>
    </div>
  );
}