import { motion } from 'motion/react';
import { Zap, Shield, TrendingUp, Check, ArrowRight, ArrowLeft, BarChart } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';

export default function SaasLanding() {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-white">
      {/* Back Button */}
      <Link to="/portfolio">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed top-24 left-4 z-50 bg-blue-600 text-white px-4 py-2 rounded-full shadow-lg hover:bg-blue-700 transition-all flex items-center gap-2 group"
        >
          <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
          <span className="hidden sm:inline">{t('common.backToProducts')}</span>
        </motion.button>
      </Link>

      <nav className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Zap className="text-blue-600" size={28} />
              <h2 className="text-gray-900">DataFlow</h2>
            </div>
            <div className="hidden md:flex gap-6">
              <a href="#" className="text-gray-600 hover:text-blue-600">Features</a>
              <a href="#" className="text-gray-600 hover:text-blue-600">Pricing</a>
              <a href="#" className="text-gray-600 hover:text-blue-600">Customers</a>
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" className="text-gray-600">Sign In</Button>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">Start Free</Button>
            </div>
          </div>
        </div>
      </nav>

      <section className="py-24 bg-gradient-to-b from-blue-50 to-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Badge className="mb-6 bg-blue-100 text-blue-700">Trusted by 10,000+ teams</Badge>
            <h1 className="text-gray-900 mb-6 text-6xl">
              Analytics That
              <br />
              <span className="text-blue-600">Drive Growth</span>
            </h1>
            <p className="text-gray-600 text-xl mb-8 max-w-2xl mx-auto">
              Make data-driven decisions with real-time insights and powerful analytics tools.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg">
                Start 14-Day Free Trial
                <ArrowRight className="ml-2" size={20} />
              </Button>
              <Button variant="outline" className="border-2 border-gray-300 text-gray-700 px-8 py-6 text-lg">
                Watch Demo
              </Button>
            </div>
            <p className="text-gray-500 mt-4 text-sm">No credit card required • Cancel anytime</p>
          </motion.div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-gray-900 mb-4">Everything You Need</h2>
            <p className="text-gray-600 text-lg">Powerful features to supercharge your workflow</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: BarChart, title: 'Real-Time Analytics', desc: 'Monitor your metrics as they happen' },
              { icon: Zap, title: 'Fast Performance', desc: 'Lightning-fast data processing' },
              { icon: Check, title: 'Easy Integration', desc: 'Connect with your favorite tools' },
            ].map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="border-gray-200 hover:shadow-lg transition-shadow">
                  <CardContent className="p-8">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                      <feature.icon className="text-blue-600" size={24} />
                    </div>
                    <h3 className="text-gray-900 mb-2">{feature.title}</h3>
                    <p className="text-gray-600">{feature.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-gray-900 mb-4">Simple, Transparent Pricing</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { name: 'Starter', price: 29, features: ['Up to 10 users', 'Basic analytics', 'Email support'] },
                { name: 'Pro', price: 79, features: ['Unlimited users', 'Advanced analytics', 'Priority support', 'Custom integrations'], popular: true },
                { name: 'Enterprise', price: 199, features: ['Everything in Pro', 'Dedicated support', 'SLA guarantee', 'Custom training'] },
              ].map((plan) => (
                <Card key={plan.name} className={`${plan.popular ? 'border-2 border-blue-600 shadow-xl scale-105' : 'border-gray-200'}`}>
                  <CardContent className="p-8">
                    {plan.popular && <Badge className="mb-4 bg-blue-600 text-white">Most Popular</Badge>}
                    <h3 className="text-gray-900 mb-2">{plan.name}</h3>
                    <div className="mb-6">
                      <span className="text-4xl text-gray-900">${plan.price}</span>
                      <span className="text-gray-600">/month</span>
                    </div>
                    <ul className="space-y-3 mb-8">
                      {plan.features.map((feature) => (
                        <li key={feature} className="flex items-center gap-2 text-gray-600">
                          <Check size={18} className="text-blue-600" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <Button className={`w-full ${plan.popular ? 'bg-blue-600 hover:bg-blue-700 text-white' : 'bg-gray-100 text-gray-900 hover:bg-gray-200'}`}>
                      Get Started
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-blue-600">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <h2 className="mb-6">Ready to get started?</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Join thousands of teams already using DataFlow to make better decisions.
          </p>
          <Button className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-6 text-lg">
            Start Your Free Trial
          </Button>
        </div>
      </section>
    </div>
  );
}