import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowLeft, ShoppingBag, Heart, Search, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export default function FashionStore() {
  const { t } = useLanguage();
  
  const products = [
    { id: 1, name: 'Elegant Dress', price: 299, category: 'Women', rating: 4.8, image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=500' },
    { id: 2, name: 'Classic Blazer', price: 399, category: 'Men', rating: 4.9, image: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=500' },
    { id: 3, name: 'Summer Collection', price: 199, category: 'Women', rating: 4.7, image: 'https://images.unsplash.com/photo-1539008835657-9e8e9680c956?w=500' },
    { id: 4, name: 'Urban Sneakers', price: 159, category: 'Shoes', rating: 4.6, image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500' },
    { id: 5, name: 'Leather Bag', price: 249, category: 'Accessories', rating: 4.8, image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=500' },
    { id: 6, name: 'Designer Watch', price: 599, category: 'Accessories', rating: 4.9, image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500' },
  ];

  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      {/* Back to Portfolio Button */}
      <Link to="/portfolio">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed top-24 left-4 z-50 bg-black text-white px-4 py-2 rounded-full shadow-lg hover:bg-gray-800 transition-all flex items-center gap-2 group"
        >
          <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
          <span className="hidden sm:inline">{t('common.backToProducts')}</span>
        </motion.button>
      </Link>

      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-8">
              <h2 className="text-black">LUXE</h2>
              <div className="hidden md:flex gap-6">
                <a href="#" className="text-gray-700 hover:text-black transition-colors">New Arrivals</a>
                <a href="#" className="text-gray-700 hover:text-black transition-colors">Women</a>
                <a href="#" className="text-gray-700 hover:text-black transition-colors">Men</a>
                <a href="#" className="text-gray-700 hover:text-black transition-colors">Sale</a>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Search className="text-gray-700 cursor-pointer hover:text-black" size={20} />
              <Heart className="text-gray-700 cursor-pointer hover:text-black" size={20} />
              <div className="relative">
                <ShoppingBag className="text-gray-700 cursor-pointer hover:text-black" size={20} />
                <span className="absolute -top-2 -right-2 bg-black text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">3</span>
              </div>
              <Menu className="md:hidden text-gray-700" size={20} />
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-[600px] bg-gradient-to-r from-gray-100 to-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
          <div className="max-w-xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <Badge className="mb-4 bg-black text-white">New Season</Badge>
              <h1 className="text-black mb-6">Fall Collection 2024</h1>
              <p className="text-gray-600 text-xl mb-8">
                Discover our curated selection of premium fashion pieces that define your style
              </p>
              <Button className="bg-black text-white hover:bg-gray-800 px-8 py-6">
                Shop Now
              </Button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {['Women', 'Men', 'Accessories', 'Sale'].map((category) => (
              <Card key={category} className="group cursor-pointer hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <h3 className="text-black group-hover:text-gray-600 transition-colors">{category}</h3>
                  <p className="text-gray-500 mt-2">Shop Now →</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-black mb-4">Trending Now</h2>
            <p className="text-gray-600 text-lg">Our most loved pieces this season</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="group overflow-hidden hover:shadow-xl transition-all">
                  <div className="relative overflow-hidden aspect-square">
                    <ImageWithFallback 
                      src={product.image} 
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <Badge className="absolute top-4 right-4 bg-white text-black">
                      <Star size={12} className="inline mr-1 fill-black" />
                      {product.rating}
                    </Badge>
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
                    <Button className="absolute bottom-4 left-4 right-4 bg-white text-black hover:bg-black hover:text-white opacity-0 group-hover:opacity-100 transition-opacity">
                      Quick Add
                    </Button>
                  </div>
                  <CardContent className="p-4">
                    <p className="text-gray-500 text-sm mb-1">{product.category}</p>
                    <h3 className="text-black mb-2">{product.name}</h3>
                    <p className="text-black">${product.price}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-white border-y border-gray-200">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: TrendingUp, title: 'Premium Quality', desc: 'Only the finest materials' },
              { icon: ShoppingBag, title: 'Free Shipping', desc: 'On orders over $100' },
              { icon: Star, title: 'Easy Returns', desc: '30-day return policy' },
            ].map((feature) => (
              <div key={feature.title} className="text-center">
                <feature.icon className="mx-auto mb-4 text-black" size={32} />
                <h3 className="text-black mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="mb-4">LUXE</h3>
              <p className="text-gray-400">Premium fashion for the modern lifestyle</p>
            </div>
            <div>
              <h4 className="mb-4">Shop</h4>
              <div className="space-y-2 text-gray-400">
                <p className="hover:text-white cursor-pointer">Women</p>
                <p className="hover:text-white cursor-pointer">Men</p>
                <p className="hover:text-white cursor-pointer">Accessories</p>
              </div>
            </div>
            <div>
              <h4 className="mb-4">Support</h4>
              <div className="space-y-2 text-gray-400">
                <p className="hover:text-white cursor-pointer">Contact</p>
                <p className="hover:text-white cursor-pointer">Shipping</p>
                <p className="hover:text-white cursor-pointer">Returns</p>
              </div>
            </div>
            <div>
              <h4 className="mb-4">Newsletter</h4>
              <p className="text-gray-400 mb-4">Get the latest updates</p>
              <div className="flex gap-2">
                <input 
                  type="email" 
                  placeholder="Email" 
                  className="px-4 py-2 bg-white/10 border border-white/20 rounded flex-1 text-white"
                />
                <Button className="bg-white text-black hover:bg-gray-200">Subscribe</Button>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>&copy; 2024 LUXE. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}