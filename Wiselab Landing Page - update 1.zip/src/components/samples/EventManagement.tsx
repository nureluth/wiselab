import { motion } from 'motion/react';
import { Calendar, Users, MapPin, Star, Award, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export default function EventManagement() {
  const { t } = useLanguage();
  const events = [
    { id: 1, title: 'Tech Summit 2024', date: 'Dec 15, 2024', attendees: 500, image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=600' },
    { id: 2, title: 'Music Festival', date: 'Jan 20, 2025', attendees: 2000, image: 'https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=600' },
    { id: 3, title: 'Business Conference', date: 'Feb 10, 2025', attendees: 300, image: 'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=600' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-fuchsia-50 to-cyan-50">
      {/* Back Button */}
      <Link to="/portfolio">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed top-24 left-4 z-50 bg-fuchsia-600 text-white px-4 py-2 rounded-full shadow-lg hover:bg-fuchsia-700 transition-all flex items-center gap-2 group"
        >
          <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
          <span className="hidden sm:inline">{t('common.backToProducts')}</span>
        </motion.button>
      </Link>

      <nav className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Calendar className="text-fuchsia-600" size={28} />
              <h2 className="text-gray-900">EventPro</h2>
            </div>
            <div className="hidden md:flex gap-6">
              <a href="#" className="text-gray-600 hover:text-fuchsia-600">Events</a>
              <a href="#" className="text-gray-600 hover:text-fuchsia-600">Services</a>
              <a href="#" className="text-gray-600 hover:text-fuchsia-600">About</a>
            </div>
            <Button className="bg-fuchsia-600 hover:bg-fuchsia-700 text-white">Plan Your Event</Button>
          </div>
        </div>
      </nav>

      <section className="py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-gray-900 mb-6">
              Create Unforgettable
              <span className="text-fuchsia-600"> Experiences</span>
            </h1>
            <p className="text-gray-600 text-xl mb-8">
              Professional event planning and management services for corporate events, weddings, and celebrations
            </p>
            <Button className="bg-fuchsia-600 hover:bg-fuchsia-700 text-white px-8 py-6 text-lg">
              Get Started
            </Button>
          </motion.div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-gray-900 mb-4">Upcoming Events</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {events.map((event, index) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="overflow-hidden hover:shadow-xl transition-shadow">
                  <div className="relative h-48">
                    <ImageWithFallback 
                      src={event.image}
                      alt={event.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-6">
                    <h3 className="text-gray-900 mb-2">{event.title}</h3>
                    <div className="space-y-2 text-gray-600 mb-4">
                      <div className="flex items-center gap-2">
                        <Calendar size={16} />
                        <span className="text-sm">{event.date}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users size={16} />
                        <span className="text-sm">{event.attendees} Attendees</span>
                      </div>
                    </div>
                    <Button className="w-full bg-fuchsia-600 hover:bg-fuchsia-700 text-white">
                      Register Now
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-r from-fuchsia-600 to-purple-600 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            {[
              { icon: Award, value: '500+', label: 'Events Hosted' },
              { icon: Users, value: '50K+', label: 'Happy Attendees' },
              { icon: Star, value: '4.9', label: 'Average Rating' },
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <stat.icon className="mx-auto mb-4" size={40} />
                <div className="text-4xl mb-2">{stat.value}</div>
                <div className="text-fuchsia-100">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-gray-900 mb-6">Ready to Plan Your Next Event?</h2>
          <p className="text-gray-600 text-lg mb-8 max-w-2xl mx-auto">
            Let's create something amazing together. Contact us for a free consultation.
          </p>
          <Button className="bg-fuchsia-600 hover:bg-fuchsia-700 text-white px-8 py-6">
            Contact Us Today
          </Button>
        </div>
      </section>
    </div>
  );
}