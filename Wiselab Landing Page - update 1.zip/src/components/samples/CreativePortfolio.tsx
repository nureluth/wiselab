import { motion } from 'motion/react';
import { Dribbble, Instagram, Twitter, ArrowRight, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export default function CreativePortfolio() {
  const { t } = useLanguage();
  const works = [
    { id: 1, title: 'Brand Identity', category: 'Design', image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=600' },
    { id: 2, title: 'Mobile App', category: 'UI/UX', image: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=600' },
    { id: 3, title: 'Web Platform', category: 'Development', image: 'https://images.unsplash.com/photo-1547658719-da2b51169166?w=600' },
    { id: 4, title: 'Marketing Campaign', category: 'Design', image: 'https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?w=600' },
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Back Button */}
      <Link to="/portfolio">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed top-24 left-4 z-50 bg-white text-black px-4 py-2 rounded-full shadow-lg hover:bg-gray-100 transition-all flex items-center gap-2 group"
        >
          <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
          <span className="hidden sm:inline">{t('common.backToProducts')}</span>
        </motion.button>
      </Link>

      <nav className="bg-black/50 backdrop-blur-sm sticky top-0 z-50 py-6">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl">Alex Morgan</h2>
            <div className="hidden md:flex gap-8 text-gray-400">
              <a href="#work" className="hover:text-white transition-colors">Work</a>
              <a href="#about" className="hover:text-white transition-colors">About</a>
              <a href="#contact" className="hover:text-white transition-colors">Contact</a>
            </div>
          </div>
        </div>
      </nav>

      <section className="py-32">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="max-w-4xl"
          >
            <h1 className="text-7xl mb-8 leading-tight">
              Creative Designer
              <br />
              & <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-violet-500">Developer</span>
            </h1>
            <p className="text-gray-400 text-xl mb-12 max-w-2xl">
              I craft beautiful digital experiences that combine stunning design with powerful functionality.
            </p>
            <Button className="bg-white text-black hover:bg-gray-100 px-8 py-6 group">
              View My Work
              <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
            </Button>
          </motion.div>
        </div>
      </section>

      <section id="work" className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="mb-16">Selected Work</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {works.map((work, index) => (
              <motion.div
                key={work.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                className="group cursor-pointer"
              >
                <div className="relative h-96 overflow-hidden rounded-lg mb-4">
                  <ImageWithFallback 
                    src={work.image}
                    alt={work.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="mb-1">{work.title}</h3>
                    <p className="text-gray-500">{work.category}</p>
                  </div>
                  <ArrowRight className="text-gray-500 group-hover:text-white group-hover:translate-x-2 transition-all" size={24} />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="py-32 border-t border-gray-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="mb-8">Let's Work Together</h2>
            <p className="text-gray-400 text-xl mb-12">
              Have a project in mind? I'd love to hear about it.
            </p>
            <Button className="bg-white text-black hover:bg-gray-100 px-8 py-6 text-lg">
              Get In Touch
            </Button>
            <div className="flex justify-center gap-6 mt-12">
              <Dribbble className="text-gray-600 hover:text-white cursor-pointer transition-colors" size={24} />
              <Instagram className="text-gray-600 hover:text-white cursor-pointer transition-colors" size={24} />
              <Twitter className="text-gray-600 hover:text-white cursor-pointer transition-colors" size={24} />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}