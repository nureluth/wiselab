import { motion } from 'motion/react';
import { Home, MapPin, Bath, Bed, Car, Search, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../contexts/LanguageContext';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export default function RealEstate() {
  const { t } = useLanguage();
  const properties = [
    { id: 1, title: 'Modern Downtown Condo', price: '850,000', beds: 2, baths: 2, sqft: '1,200', image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=600' },
    { id: 2, title: 'Luxury Family Home', price: '1,250,000', beds: 4, baths: 3, sqft: '2,800', image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600' },
    { id: 3, title: 'Beachfront Villa', price: '2,100,000', beds: 5, baths: 4, sqft: '3,500', image: 'https://images.unsplash.com/photo-1613977257363-707ba9348227?w=600' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Back Button */}
      <Link to="/portfolio">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed top-24 left-4 z-50 bg-emerald-600 text-white px-4 py-2 rounded-full shadow-lg hover:bg-emerald-700 transition-all flex items-center gap-2 group"
        >
          <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
          <span className="hidden sm:inline">{t('common.backToProducts')}</span>
        </motion.button>
      </Link>

      <nav className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Home className="text-emerald-600" size={28} />
              <h2 className="text-gray-900">EstateView</h2>
            </div>
            <div className="hidden md:flex gap-6">
              <a href="#" className="text-gray-600 hover:text-emerald-600">Buy</a>
              <a href="#" className="text-gray-600 hover:text-emerald-600">Rent</a>
              <a href="#" className="text-gray-600 hover:text-emerald-600">Sell</a>
            </div>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">Contact Us</Button>
          </div>
        </div>
      </nav>

      <section className="py-24 bg-gradient-to-r from-emerald-600 to-teal-600 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="mb-6">Find Your Dream Home</h1>
            <p className="text-xl text-emerald-50 mb-8 max-w-2xl mx-auto">
              Discover the perfect property from our exclusive collection of premium listings
            </p>
            <Card className="max-w-3xl mx-auto bg-white p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <input placeholder="Location" className="px-4 py-3 border rounded-lg outline-none" />
                <select className="px-4 py-3 border rounded-lg outline-none">
                  <option>Property Type</option>
                  <option>House</option>
                  <option>Apartment</option>
                  <option>Villa</option>
                </select>
                <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">Search</Button>
              </div>
            </Card>
          </motion.div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-12">
            <h2 className="text-gray-900 mb-4">Featured Properties</h2>
            <p className="text-gray-600 text-lg">Handpicked properties just for you</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {properties.map((property, index) => (
              <motion.div
                key={property.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="overflow-hidden hover:shadow-xl transition-shadow">
                  <div className="relative h-56">
                    <ImageWithFallback 
                      src={property.image}
                      alt={property.title}
                      className="w-full h-full object-cover"
                    />
                    <Badge className="absolute top-4 right-4 bg-emerald-600 text-white">For Sale</Badge>
                  </div>
                  <CardContent className="p-6">
                    <h3 className="text-gray-900 mb-2">{property.title}</h3>
                    <div className="text-2xl text-emerald-600 mb-4">${property.price}</div>
                    <div className="flex gap-4 text-gray-600 text-sm">
                      <span className="flex items-center gap-1">
                        <Bed size={16} />
                        {property.beds} Beds
                      </span>
                      <span className="flex items-center gap-1">
                        <Bath size={16} />
                        {property.baths} Baths
                      </span>
                      <span className="flex items-center gap-1">
                        <Square size={16} />
                        {property.sqft} sqft
                      </span>
                    </div>
                    <Button className="w-full mt-4 bg-emerald-600 hover:bg-emerald-700 text-white">
                      View Details
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-emerald-600 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="mb-6">Ready to Make a Move?</h2>
          <p className="text-xl text-emerald-50 mb-8 max-w-2xl mx-auto">
            Let our expert agents help you find the perfect property
          </p>
          <Button className="bg-white text-emerald-600 hover:bg-emerald-50 px-8 py-6">
            Schedule a Viewing
          </Button>
        </div>
      </section>
    </div>
  );
}