import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Plane, MapPin, Calendar, Star, Users, Shield } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export default function TravelAgency() {
  const { t } = useLanguage();
  const destinations = [
    { id: 1, name: 'Bali, Indonesia', price: 899, rating: 4.9, image: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=500', duration: '7 days' },
    { id: 2, name: 'Paris, France', price: 1299, rating: 4.8, image: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=500', duration: '5 days' },
    { id: 3, name: 'Tokyo, Japan', price: 1499, rating: 4.9, image: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=500', duration: '6 days' },
    { id: 4, name: 'Santorini, Greece', price: 1199, rating: 4.7, image: 'https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?w=500', duration: '5 days' },
    { id: 5, name: 'Dubai, UAE', price: 999, rating: 4.8, image: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=500', duration: '4 days' },
    { id: 6, name: 'Maldives', price: 1799, rating: 5.0, image: 'https://images.unsplash.com/photo-1514282401047-d79a71a590e8?w=500', duration: '7 days' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 to-white">
      {/* Back to Portfolio Button */}
      <Link to="/portfolio">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed top-24 left-4 z-50 bg-sky-600 text-white px-4 py-2 rounded-full shadow-lg hover:bg-sky-700 transition-all flex items-center gap-2 group"
        >
          <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
          <span className="hidden sm:inline">{t('common.backToProducts')}</span>
        </motion.button>
      </Link>

      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Plane className="text-sky-600" size={28} />
              <h2 className="text-sky-600">WanderLust</h2>
            </div>
            <div className="hidden md:flex gap-6">
              <a href="#destinations" className="text-gray-700 hover:text-sky-600 transition-colors">Destinations</a>
              <a href="#tours" className="text-gray-700 hover:text-sky-600 transition-colors">Tours</a>
              <a href="#about" className="text-gray-700 hover:text-sky-600 transition-colors">About</a>
              <a href="#contact" className="text-gray-700 hover:text-sky-600 transition-colors">Contact</a>
            </div>
            <Button className="bg-sky-600 text-white hover:bg-sky-700">Book Now</Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-[700px]">
        <div className="absolute inset-0">
          <ImageWithFallback 
            src="https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=1920"
            alt="Travel"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-sky-900/60 via-sky-900/40 to-transparent" />
        </div>
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center items-center text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-4xl"
          >
            <h1 className="text-white mb-6">
              Explore the World,
              <br />
              Create Memories
            </h1>
            <p className="text-white/90 text-xl mb-12">
              Discover amazing destinations and unforgettable experiences with our curated travel packages
            </p>

            {/* Search Box */}
            <Card className="bg-white p-6 max-w-3xl mx-auto">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="flex items-center gap-2 border-b md:border-b-0 md:border-r border-gray-200 pb-4 md:pb-0 pr-0 md:pr-4">
                  <MapPin className="text-sky-600" size={20} />
                  <input 
                    type="text" 
                    placeholder="Where to?" 
                    className="outline-none flex-1"
                  />
                </div>
                <div className="flex items-center gap-2 border-b md:border-b-0 md:border-r border-gray-200 pb-4 md:pb-0 pr-0 md:pr-4">
                  <Calendar className="text-sky-600" size={20} />
                  <input 
                    type="text" 
                    placeholder="When?" 
                    className="outline-none flex-1"
                  />
                </div>
                <div className="flex items-center gap-2 border-b md:border-b-0 md:border-r border-gray-200 pb-4 md:pb-0 pr-0 md:pr-4">
                  <Users className="text-sky-600" size={20} />
                  <input 
                    type="text" 
                    placeholder="Travelers" 
                    className="outline-none flex-1"
                  />
                </div>
                <Button className="bg-sky-600 text-white hover:bg-sky-700">
                  <Search size={20} className="mr-2" />
                  Search
                </Button>
              </div>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Featured Destinations */}
      <section id="destinations" className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-gray-900 mb-4">Popular Destinations</h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Handpicked destinations for your next adventure
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {destinations.map((destination, index) => (
              <motion.div
                key={destination.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="overflow-hidden group hover:shadow-2xl transition-all border-0">
                  <div className="relative h-64 overflow-hidden">
                    <ImageWithFallback 
                      src={destination.image}
                      alt={destination.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                    <Badge className="absolute top-4 right-4 bg-sky-600 text-white border-0">
                      <Star size={12} className="inline mr-1 fill-white" />
                      {destination.rating}
                    </Badge>
                    <div className="absolute bottom-4 left-4 right-4 text-white">
                      <h3 className="mb-1">{destination.name}</h3>
                      <div className="flex items-center gap-2 text-sm text-white/80">
                        <Calendar size={16} />
                        <span>{destination.duration}</span>
                      </div>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <p className="text-gray-500 text-sm">Starting from</p>
                        <p className="text-2xl text-gray-900">${destination.price}</p>
                      </div>
                      <Button className="bg-sky-600 text-white hover:bg-sky-700">
                        View Details
                      </Button>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <span className="flex items-center gap-1">
                        <Plane size={16} />
                        Flights included
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin size={16} />
                        Hotel
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-sky-600">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-white mb-4">Why Travel With Us</h2>
            <p className="text-sky-100 text-lg">We make your journey memorable and hassle-free</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { icon: Star, title: 'Best Prices', desc: 'Competitive rates guaranteed' },
              { icon: Users, title: 'Expert Guides', desc: 'Professional local guides' },
              { icon: Plane, title: 'Worldwide', desc: '100+ destinations' },
              { icon: Shield, title: 'Easy Booking', desc: 'Simple & secure process' },
            ].map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="text-white" size={32} />
                </div>
                <h3 className="text-white mb-2">{feature.title}</h3>
                <p className="text-sky-100">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-gray-900 mb-4">What Our Travelers Say</h2>
            <p className="text-gray-600 text-lg">Real experiences from real people</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { name: 'Jessica Lee', trip: 'Bali Adventure', text: 'Amazing experience! Everything was perfectly organized.', rating: 5 },
              { name: 'David Miller', trip: 'Paris Romance', text: 'A dream come true. WanderLust made it unforgettable.', rating: 5 },
              { name: 'Sarah Kim', trip: 'Tokyo Explorer', text: 'Best vacation ever! Highly recommend their services.', rating: 5 },
            ].map((testimonial, index) => (
              <motion.div
                key={testimonial.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="border-sky-100">
                  <CardContent className="p-6">
                    <div className="flex gap-1 mb-4">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} size={16} className="fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <p className="text-gray-700 mb-4 italic">"{testimonial.text}"</p>
                    <div>
                      <p className="text-gray-900">{testimonial.name}</p>
                      <p className="text-gray-500 text-sm">{testimonial.trip}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-20 bg-gradient-to-r from-sky-500 to-sky-600">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-white mb-4">Get Travel Inspiration</h2>
          <p className="text-sky-100 text-lg mb-8 max-w-2xl mx-auto">
            Subscribe to our newsletter for exclusive deals and travel tips
          </p>
          <div className="max-w-md mx-auto flex gap-2">
            <input 
              type="email" 
              placeholder="Enter your email" 
              className="px-6 py-4 rounded-lg flex-1 outline-none"
            />
            <Button className="bg-white text-sky-600 hover:bg-sky-50 px-8">
              Subscribe
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Plane className="text-sky-500" size={24} />
                <h3>WanderLust</h3>
              </div>
              <p className="text-gray-400">Your journey begins here</p>
            </div>
            <div>
              <h4 className="mb-4">Quick Links</h4>
              <div className="space-y-2 text-gray-400">
                <p className="hover:text-white cursor-pointer">About Us</p>
                <p className="hover:text-white cursor-pointer">Destinations</p>
                <p className="hover:text-white cursor-pointer">Tours</p>
              </div>
            </div>
            <div>
              <h4 className="mb-4">Support</h4>
              <div className="space-y-2 text-gray-400">
                <p className="hover:text-white cursor-pointer">Contact</p>
                <p className="hover:text-white cursor-pointer">FAQ</p>
                <p className="hover:text-white cursor-pointer">Terms</p>
              </div>
            </div>
            <div>
              <h4 className="mb-4">Contact</h4>
              <div className="space-y-2 text-gray-400">
                <p>info@wanderlust.com</p>
                <p>+1 (555) 123-4567</p>
                <p>New York, USA</p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>&copy; 2024 WanderLust. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}