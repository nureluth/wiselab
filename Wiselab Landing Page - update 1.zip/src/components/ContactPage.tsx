import { motion } from 'motion/react';
import { useState } from 'react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Mail, MapPin, Send } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import bgImage from 'figma:asset/e25ad44609a4a09cb46cb699c8fbe72bfc05c657.png';
import { toast } from 'sonner@2.0.3';

export default function ContactPage() {
  const { t, language } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    service: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    const successMessage = language === 'id' 
      ? 'Pesan Anda telah terkirim! Kami akan menghubungi Anda segera.'
      : 'Your message has been sent! We will contact you shortly.';
    toast.success(successMessage);
    setFormData({
      name: '',
      email: '',
      company: '',
      service: '',
      message: '',
    });
  };

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section
        className="relative py-24 overflow-hidden"
        style={{
          backgroundImage: `url(${bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-[#0A192F]/90" />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-white mb-6">{t('contactPage.title')}</h1>
            <p className="text-gray-300 text-xl">
              {t('contactPage.subtitle')}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-24 bg-[#0A192F]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Contact Info */}
            <div className="lg:col-span-1">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-white mb-6">{t('contactPage.getInTouch')}</h2>
                  <p className="text-gray-400 mb-8">
                    {t('contactPage.getInTouchDesc')}
                  </p>
                </div>

                <Card className="bg-[#112240] border-gray-700">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4 mb-6">
                      <div className="p-3 bg-[#64FFDA]/10 rounded-lg">
                        <Mail className="text-[#64FFDA]" size={24} />
                      </div>
                      <div>
                        <div className="text-gray-400 mb-1">Email</div>
                        <a
                          href="mailto:wiselabco@gmail.com"
                          className="text-white hover:text-[#64FFDA] transition-colors"
                        >
                          wiselabco@gmail.com
                        </a>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="p-3 bg-[#64FFDA]/10 rounded-lg">
                        <MapPin className="text-[#64FFDA]" size={24} />
                      </div>
                      <div>
                        <div className="text-gray-400 mb-1">
                          {language === 'id' ? 'Alamat' : 'Address'}
                        </div>
                        <p className="text-white">
                          Amega Crown Residence, Sidoarjo, Indonesia
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Map Placeholder */}
                <Card className="bg-[#112240] border-gray-700 overflow-hidden">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4255.90738802891!2d112.79680707532111!3d-7.346437192662274!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7e552902e2e41%3A0x8eef9a3c81618d3c!2sAmega%20Crown%20Residence!5e1!3m2!1sid!2sid!4v1762610324586!5m2!1sid!2sid"
                    width="100%"
                    height="256"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    title="Wiselab Location - Amega Crown Residence"
                  />
                </Card>
              </motion.div>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
              >
                <Card className="bg-[#112240] border-gray-700">
                  <CardContent className="p-8">
                    <h3 className="text-white mb-6">
                      {language === 'id' ? 'Kirim Pesan' : 'Send Message'}
                    </h3>
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <Label htmlFor="name" className="text-gray-300">
                            {t('contactPage.name')} *
                          </Label>
                          <Input
                            id="name"
                            value={formData.name}
                            onChange={(e) => handleChange('name', e.target.value)}
                            required
                            className="mt-2 bg-[#0A192F] border-gray-700 text-white focus:border-[#64FFDA]"
                            placeholder={language === 'id' ? 'Masukkan nama Anda' : 'Enter your name'}
                          />
                        </div>

                        <div>
                          <Label htmlFor="email" className="text-gray-300">
                            {t('contactPage.email')} *
                          </Label>
                          <Input
                            id="email"
                            type="email"
                            value={formData.email}
                            onChange={(e) => handleChange('email', e.target.value)}
                            required
                            className="mt-2 bg-[#0A192F] border-gray-700 text-white focus:border-[#64FFDA]"
                            placeholder="email@example.com"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <Label htmlFor="company" className="text-gray-300">
                            {t('contactPage.company')}
                          </Label>
                          <Input
                            id="company"
                            value={formData.company}
                            onChange={(e) => handleChange('company', e.target.value)}
                            className="mt-2 bg-[#0A192F] border-gray-700 text-white focus:border-[#64FFDA]"
                            placeholder={language === 'id' ? 'Nama perusahaan Anda' : 'Your company name'}
                          />
                        </div>

                        <div>
                          <Label htmlFor="service" className="text-gray-300">
                            {t('contactPage.service')} *
                          </Label>
                          <Select
                            value={formData.service}
                            onValueChange={(value) => handleChange('service', value)}
                            required
                          >
                            <SelectTrigger className="mt-2 bg-[#0A192F] border-gray-700 text-white focus:border-[#64FFDA]">
                              <SelectValue placeholder={language === 'id' ? 'Pilih layanan' : 'Select service'} />
                            </SelectTrigger>
                            <SelectContent className="bg-[#0A192F] border-gray-700 text-white">
                              <SelectItem value="uiux">
                                {language === 'id' ? 'Desain UI/UX' : 'UI/UX Design'}
                              </SelectItem>
                              <SelectItem value="web">
                                {language === 'id' ? 'Pengembangan Web' : 'Web Development'}
                              </SelectItem>
                              <SelectItem value="mobile">
                                {language === 'id' ? 'Aplikasi Mobile' : 'Mobile App'}
                              </SelectItem>
                              <SelectItem value="qa">Quality Assurance</SelectItem>
                              <SelectItem value="hosting">
                                {language === 'id' ? 'Hosting & Infrastruktur' : 'Hosting & Infrastructure'}
                              </SelectItem>
                              <SelectItem value="other">
                                {language === 'id' ? 'Lainnya' : 'Other'}
                              </SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="message" className="text-gray-300">
                          {t('contactPage.message')} *
                        </Label>
                        <Textarea
                          id="message"
                          value={formData.message}
                          onChange={(e) => handleChange('message', e.target.value)}
                          required
                          rows={6}
                          className="mt-2 bg-[#0A192F] border-gray-700 text-white focus:border-[#64FFDA] resize-none"
                          placeholder={language === 'id' ? 'Ceritakan tentang proyek Anda...' : 'Tell us about your project...'}
                        />
                      </div>

                      <Button
                        type="submit"
                        className="w-full bg-[#64FFDA] text-[#0A192F] hover:bg-[#64FFDA]/90 py-6 group"
                      >
                        {t('contactPage.send')}
                        <Send className="ml-2 group-hover:translate-x-1 transition-transform" size={18} />
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
