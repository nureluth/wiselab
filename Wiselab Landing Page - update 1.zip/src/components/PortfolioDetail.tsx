import { motion } from 'motion/react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { ArrowLeft, ExternalLink } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { portfolioData } from '../data/portfolioData';
import bgImage from 'figma:asset/e25ad44609a4a09cb46cb699c8fbe72bfc05c657.png';

export default function PortfolioDetail() {
  const { id } = useParams();
  const project = portfolioData.find((p) => p.id === id);

  if (!project) {
    return (
      <div className="pt-20 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-white mb-4">Project tidak ditemukan</h2>
          <Link to="/portfolio">
            <Button className="bg-[#64FFDA] text-[#0A192F] hover:bg-[#64FFDA]/90">
              Kembali ke Portfolio
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  // If this is a sample website, redirect directly to the sample route
  if (project.isSample) {
    return <Navigate to={`/portfolio/${id}`} replace />;
  }

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section
        className="relative py-24 overflow-hidden"
        style={{
          backgroundImage: `url(${bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-[#0A192F]/90" />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Link
              to="/portfolio"
              className="inline-flex items-center gap-2 text-[#64FFDA] mb-6 hover:gap-3 transition-all"
            >
              <ArrowLeft size={20} />
              Kembali ke Produk Kami
            </Link>
            <Badge className="bg-[#64FFDA]/20 text-[#64FFDA] border-[#64FFDA]/30 mb-4">
              {project.category}
            </Badge>
            <h1 className="text-white mb-6">{project.title}</h1>
            <p className="text-gray-300 text-xl max-w-3xl mb-8">
              {project.description}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Image */}
      <section className="py-16 bg-[#0A192F]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="aspect-video overflow-hidden rounded-lg"
          >
            <ImageWithFallback
              src={project.image}
              alt={project.title}
              className="w-full h-full object-cover"
            />
          </motion.div>
        </div>
      </section>

      {/* Tags */}
      <section className="py-12 bg-[#020c1b]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap gap-3">
            {project.tags.map((tag) => (
              <Badge key={tag} className="bg-[#112240] text-gray-300 border-gray-700 px-4 py-2">
                {tag}
              </Badge>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-[#0A192F]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-white mb-6">Tertarik dengan Proyek Ini?</h2>
          <p className="text-gray-400 text-lg mb-8 max-w-2xl mx-auto">
            Hubungi kami untuk membahas bagaimana kami bisa membantu mewujudkan proyek Anda
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/contact">
              <Button className="bg-[#64FFDA] text-[#0A192F] hover:bg-[#64FFDA]/90 px-8 py-6">
                Hubungi Kami
              </Button>
            </Link>
            <Link to="/portfolio">
              <Button className="bg-transparent border-2 border-[#64FFDA] text-[#64FFDA] hover:bg-[#64FFDA] hover:text-[#0A192F] px-8 py-6">
                <ExternalLink size={18} className="mr-2" />
                Lihat Portfolio Lainnya
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}