import { motion } from 'motion/react';
import { Code2, Palette, Zap, Search, Server } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { useLanguage } from '../contexts/LanguageContext';

export default function ServicesSection() {
  const { t } = useLanguage();
  
  const services = [
    {
      icon: Palette,
      title: t('service.uiux.title'),
      description: t('service.uiux.desc'),
      features: ['User Research', 'Wireframing & Mockups', 'Interactive Prototypes', 'Design Systems'],
    },
    {
      icon: Code2,
      title: t('service.webdev.title'),
      description: t('service.webdev.desc'),
      features: ['Responsive Design', 'Custom Development', 'CMS Integration', 'API Development'],
    },
    {
      icon: Zap,
      title: t('service.optimization.title'),
      description: t('service.optimization.desc'),
      features: ['Performance Tuning', 'SEO Optimization', 'Speed Enhancement', 'Mobile Optimization'],
    },
    {
      icon: Search,
      title: t('service.maintenance.title'),
      description: t('service.maintenance.desc'),
      features: ['Regular Updates', 'Bug Fixes', 'Security Patches', 'Technical Support'],
    },
    {
      icon: Server,
      title: t('service.hosting.title'),
      description: t('service.hosting.desc'),
      features: ['Cloud Hosting', 'SSL Certificate', 'Backup & Recovery', 'Server Monitoring'],
      badge: t('service.comingSoon'),
    },
  ];
  
  return (
    <section className="py-24 bg-[#0A192F] relative">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-white mb-4">{t('services.title')}</h2>
          <p className="text-gray-400 text-xl max-w-2xl mx-auto">
            {t('services.subtitle')}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="bg-[#112240] border-gray-700 hover:border-[#64FFDA]/50 transition-all group h-full">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="p-3 bg-[#64FFDA]/10 rounded-lg group-hover:bg-[#64FFDA]/20 transition-colors">
                      <service.icon className="text-[#64FFDA]" size={24} />
                    </div>
                    {service.badge && (
                      <Badge className="bg-[#64FFDA]/20 text-[#64FFDA] font-bold">
                        {service.badge}
                      </Badge>
                    )}
                  </div>
                  <h3 className="text-white mb-3">{service.title}</h3>
                  <p className="text-gray-400 mb-4">{service.description}</p>
                  <ul className="space-y-2">
                    {service.features.map((feature) => (
                      <li key={feature} className="text-gray-500 flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-[#64FFDA] rounded-full" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
