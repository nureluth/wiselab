import HeroSection from './HeroSection';
import ServicesSection from './ServicesSection';
import PortfolioSection from './PortfolioSection';
import WhyUsSection from './WhyUsSection';

export default function Homepage() {
  return (
    <div>
      <HeroSection />
      <ServicesSection />
      <PortfolioSection />
      <WhyUsSection />
    </div>
  );
}