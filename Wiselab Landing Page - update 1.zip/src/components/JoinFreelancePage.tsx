import { motion } from 'motion/react';
import { useState } from 'react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { Users, Code, Palette, CheckCircle, Zap, Globe } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import bgImage from 'figma:asset/e25ad44609a4a09cb46cb699c8fbe72bfc05c657.png';
import { toast } from 'sonner@2.0.3';

export default function JoinFreelancePage() {
  const { t, language } = useLanguage();

  const benefits = [
    {
      icon: Zap,
      title: language === 'id' ? 'Proyek Berkualitas' : 'Quality Projects',
      description: language === 'id' 
        ? 'Akses ke proyek-proyek menarik dari klien ternama'
        : 'Access to exciting projects from renowned clients',
    },
    {
      icon: Globe,
      title: language === 'id' ? 'Kerja Remote' : 'Remote Work',
      description: language === 'id'
        ? 'Fleksibilitas bekerja dari mana saja'
        : 'Flexibility to work from anywhere',
    },
    {
      icon: Users,
      title: language === 'id' ? 'Tim Profesional' : 'Professional Team',
      description: language === 'id'
        ? 'Kolaborasi dengan tim yang berpengalaman'
        : 'Collaborate with experienced team',
    },
    {
      icon: CheckCircle,
      title: language === 'id' ? 'Pembayaran Tepat Waktu' : 'Timely Payment',
      description: language === 'id'
        ? 'Sistem pembayaran yang jelas dan tepat waktu'
        : 'Clear and timely payment system',
    },
  ];

  const skillCategories = [
    {
      title: 'UI/UX Designer',
      icon: Palette,
      description: language === 'id'
        ? 'Desainer dengan keahlian dalam user research, wireframing, dan visual design'
        : 'Designers with expertise in user research, wireframing, and visual design',
      skills: ['Figma', 'Adobe XD', 'Sketch', 'Prototyping', 'User Research'],
    },
    {
      title: 'Frontend Developer',
      icon: Code,
      description: language === 'id'
        ? 'Developer dengan keahlian dalam pengembangan antarmuka web modern'
        : 'Developers with expertise in modern web interface development',
      skills: ['React', 'Vue.js', 'TypeScript', 'Tailwind CSS', 'Next.js'],
    },
    {
      title: 'Backend Developer',
      icon: Code,
      description: language === 'id'
        ? 'Developer dengan keahlian dalam pengembangan sistem backend'
        : 'Developers with expertise in backend system development',
      skills: ['Node.js', 'Python', 'PostgreSQL', 'MongoDB', 'REST API'],
    },
    {
      title: 'Mobile Developer',
      icon: Code,
      description: language === 'id'
        ? 'Developer dengan keahlian dalam pengembangan aplikasi mobile'
        : 'Developers with expertise in mobile app development',
      skills: ['React Native', 'Flutter', 'iOS', 'Android', 'Firebase'],
    },
  ];

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    location: '',
    role: '',
    experience: '',
    portfolio: '',
    skills: '',
    about: '',
    availability: '',
    agreedToTerms: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.agreedToTerms) {
      const errorMessage = language === 'id'
        ? 'Harap setujui syarat dan ketentuan'
        : 'Please agree to the terms and conditions';
      toast.error(errorMessage);
      return;
    }
    const successMessage = language === 'id'
      ? 'Aplikasi Anda telah dikirim! Kami akan menghubungi Anda segera.'
      : 'Your application has been sent! We will contact you shortly.';
    toast.success(successMessage);
    setFormData({
      name: '',
      email: '',
      phone: '',
      location: '',
      role: '',
      experience: '',
      portfolio: '',
      skills: '',
      about: '',
      availability: '',
      agreedToTerms: false,
    });
  };

  const handleChange = (field: string, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section
        className="relative py-24 overflow-hidden"
        style={{
          backgroundImage: `url(${bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-[#0A192F]/90" />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-white mb-6">{t('joinFreelance.title')}</h1>
            <p className="text-gray-300 text-xl">
              {t('joinFreelance.subtitle')}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-24 bg-[#0A192F]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-white mb-4">{t('joinFreelance.why')}</h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit, index) => (
              <motion.div
                key={benefit.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="bg-[#112240] border-gray-700 hover:border-[#64FFDA]/50 transition-all h-full">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 bg-[#64FFDA]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                      <benefit.icon className="text-[#64FFDA]" size={32} />
                    </div>
                    <h3 className="text-white mb-2">{benefit.title}</h3>
                    <p className="text-gray-400">{benefit.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Skills Categories */}
      <section className="py-24 bg-[#020c1b]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-white mb-4">
              {language === 'id' ? 'Posisi yang Kami Cari' : 'Positions We Are Looking For'}
            </h2>
            <p className="text-gray-400 text-xl max-w-2xl mx-auto">
              {language === 'id' 
                ? 'Bergabunglah dengan tim kami di berbagai posisi yang tersedia'
                : 'Join our team in various available positions'}
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {skillCategories.map((category, index) => (
              <motion.div
                key={category.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="bg-[#112240] border-gray-700 hover:border-[#64FFDA]/50 transition-all h-full">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4 mb-4">
                      <div className="p-3 bg-[#64FFDA]/10 rounded-lg">
                        <category.icon className="text-[#64FFDA]" size={24} />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-white mb-2">{category.title}</h3>
                        <p className="text-gray-400 mb-4">{category.description}</p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {category.skills.map((skill) => (
                        <span
                          key={skill}
                          className="text-xs px-3 py-1 bg-[#64FFDA]/10 text-[#64FFDA] rounded-full"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Application Form */}
      <section className="py-24 bg-[#0A192F]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4">{t('joinFreelance.apply')}</h2>
            <p className="text-gray-400 text-xl">
              {language === 'id'
                ? 'Isi formulir di bawah untuk bergabung dengan tim kami'
                : 'Fill out the form below to join our team'}
            </p>
          </motion.div>

          <Card className="bg-[#112240] border-gray-700">
            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="name" className="text-gray-300">
                      {t('joinFreelance.fullName')} *
                    </Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => handleChange('name', e.target.value)}
                      required
                      className="mt-2 bg-[#0A192F] border-gray-700 text-white focus:border-[#64FFDA]"
                      placeholder={language === 'id' ? 'Nama lengkap Anda' : 'Your full name'}
                    />
                  </div>

                  <div>
                    <Label htmlFor="email" className="text-gray-300">
                      Email *
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleChange('email', e.target.value)}
                      required
                      className="mt-2 bg-[#0A192F] border-gray-700 text-white focus:border-[#64FFDA]"
                      placeholder="email@example.com"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="phone" className="text-gray-300">
                      {language === 'id' ? 'Nomor Telepon' : 'Phone Number'} *
                    </Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => handleChange('phone', e.target.value)}
                      required
                      className="mt-2 bg-[#0A192F] border-gray-700 text-white focus:border-[#64FFDA]"
                      placeholder="+62 xxx xxxx xxxx"
                    />
                  </div>

                  <div>
                    <Label htmlFor="location" className="text-gray-300">
                      {language === 'id' ? 'Lokasi' : 'Location'} *
                    </Label>
                    <Input
                      id="location"
                      value={formData.location}
                      onChange={(e) => handleChange('location', e.target.value)}
                      required
                      className="mt-2 bg-[#0A192F] border-gray-700 text-white focus:border-[#64FFDA]"
                      placeholder={language === 'id' ? 'Kota, Negara' : 'City, Country'}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="role" className="text-gray-300">
                      {language === 'id' ? 'Posisi yang Dilamar' : 'Position Applied'} *
                    </Label>
                    <Select
                      value={formData.role}
                      onValueChange={(value) => handleChange('role', value)}
                      required
                    >
                      <SelectTrigger className="mt-2 bg-[#0A192F] border-gray-700 text-white focus:border-[#64FFDA]">
                        <SelectValue placeholder={language === 'id' ? 'Pilih posisi' : 'Select position'} />
                      </SelectTrigger>
                      <SelectContent className="bg-[#0A192F] border-gray-700 text-white">
                        <SelectItem value="uiux">UI/UX Designer</SelectItem>
                        <SelectItem value="frontend">Frontend Developer</SelectItem>
                        <SelectItem value="backend">Backend Developer</SelectItem>
                        <SelectItem value="mobile">Mobile Developer</SelectItem>
                        <SelectItem value="fullstack">Fullstack Developer</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="experience" className="text-gray-300">
                      {t('joinFreelance.experience')} *
                    </Label>
                    <Select
                      value={formData.experience}
                      onValueChange={(value) => handleChange('experience', value)}
                      required
                    >
                      <SelectTrigger className="mt-2 bg-[#0A192F] border-gray-700 text-white focus:border-[#64FFDA]">
                        <SelectValue placeholder={language === 'id' ? 'Pilih pengalaman' : 'Select experience'} />
                      </SelectTrigger>
                      <SelectContent className="bg-[#0A192F] border-gray-700 text-white">
                        <SelectItem value="0-1">{language === 'id' ? '0-1 tahun' : '0-1 years'}</SelectItem>
                        <SelectItem value="1-3">{language === 'id' ? '1-3 tahun' : '1-3 years'}</SelectItem>
                        <SelectItem value="3-5">{language === 'id' ? '3-5 tahun' : '3-5 years'}</SelectItem>
                        <SelectItem value="5+">{language === 'id' ? '5+ tahun' : '5+ years'}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="portfolio" className="text-gray-300">
                    {t('joinFreelance.portfolio')} *
                  </Label>
                  <Input
                    id="portfolio"
                    type="url"
                    value={formData.portfolio}
                    onChange={(e) => handleChange('portfolio', e.target.value)}
                    required
                    className="mt-2 bg-[#0A192F] border-gray-700 text-white focus:border-[#64FFDA]"
                    placeholder="https://yourportfolio.com"
                  />
                </div>

                <div>
                  <Label htmlFor="skills" className="text-gray-300">
                    {language === 'id' ? 'Keahlian Utama' : 'Main Skills'} *
                  </Label>
                  <Input
                    id="skills"
                    value={formData.skills}
                    onChange={(e) => handleChange('skills', e.target.value)}
                    required
                    className="mt-2 bg-[#0A192F] border-gray-700 text-white focus:border-[#64FFDA]"
                    placeholder={language === 'id' ? 'React, TypeScript, Figma, dll' : 'React, TypeScript, Figma, etc'}
                  />
                </div>

                <div>
                  <Label htmlFor="about" className="text-gray-300">
                    {t('joinFreelance.about')} *
                  </Label>
                  <Textarea
                    id="about"
                    value={formData.about}
                    onChange={(e) => handleChange('about', e.target.value)}
                    required
                    rows={5}
                    className="mt-2 bg-[#0A192F] border-gray-700 text-white focus:border-[#64FFDA] resize-none"
                    placeholder={language === 'id' 
                      ? 'Ceritakan tentang diri Anda dan pengalaman Anda...'
                      : 'Tell us about yourself and your experience...'}
                  />
                </div>

                <div>
                  <Label htmlFor="availability" className="text-gray-300">
                    {language === 'id' ? 'Ketersediaan' : 'Availability'} *
                  </Label>
                  <Select
                    value={formData.availability}
                    onValueChange={(value) => handleChange('availability', value)}
                    required
                  >
                    <SelectTrigger className="mt-2 bg-[#0A192F] border-gray-700 text-white focus:border-[#64FFDA]">
                      <SelectValue placeholder={language === 'id' ? 'Pilih ketersediaan' : 'Select availability'} />
                    </SelectTrigger>
                    <SelectContent className="bg-[#0A192F] border-gray-700 text-white">
                      <SelectItem value="fulltime">
                        {language === 'id' ? 'Full-time (40 jam/minggu)' : 'Full-time (40 hours/week)'}
                      </SelectItem>
                      <SelectItem value="parttime">
                        {language === 'id' ? 'Part-time (20 jam/minggu)' : 'Part-time (20 hours/week)'}
                      </SelectItem>
                      <SelectItem value="project">
                        {language === 'id' ? 'Berbasis Proyek' : 'Project-based'}
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-start gap-2">
                  <Checkbox
                    id="terms"
                    checked={formData.agreedToTerms}
                    onCheckedChange={(checked) => handleChange('agreedToTerms', checked as boolean)}
                    className="mt-1 border-gray-600 data-[state=checked]:bg-[#64FFDA] data-[state=checked]:border-[#64FFDA]"
                  />
                  <Label htmlFor="terms" className="text-gray-300 cursor-pointer">
                    {language === 'id'
                      ? 'Saya setuju dengan syarat dan ketentuan yang berlaku'
                      : 'I agree to the terms and conditions'}
                  </Label>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-[#64FFDA] text-[#0A192F] hover:bg-[#64FFDA]/90 py-6"
                >
                  {t('joinFreelance.submit')}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
