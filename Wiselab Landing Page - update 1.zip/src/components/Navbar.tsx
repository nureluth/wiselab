import { Link, useLocation } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { Menu, X, Globe } from 'lucide-react';
import { Button } from './ui/button';
import { useLanguage } from '../contexts/LanguageContext';
import logoImage from 'figma:asset/367410809346896deab2407afda0833b661a4148.png';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();
  const { language, setLanguage, t } = useLanguage();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: t('nav.home'), path: '/' },
    { name: t('nav.services'), path: '/services' },
    { name: t('nav.products'), path: '/portfolio' },
    { name: t('nav.joinFreelance'), path: '/join-freelance' },
    { name: t('nav.contact'), path: '/contact' },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled || isMobileMenuOpen ? 'bg-[#0A192F]/95 backdrop-blur-md shadow-lg' : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <img src={logoImage} alt="Wiselab Logo" className="h-10 w-10 transition-transform group-hover:scale-110" />
            <span className="text-white text-2xl tracking-tight">Wiselab</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`relative transition-colors ${
                  location.pathname === link.path
                    ? 'text-[#64FFDA]'
                    : 'text-gray-300 hover:text-[#64FFDA]'
                }`}
              >
                {link.name}
                {location.pathname === link.path && (
                  <span className="absolute -bottom-1 left-0 right-0 h-0.5 bg-[#64FFDA]" />
                )}
              </Link>
            ))}
            
            {/* Language Switcher */}
            <div className="flex items-center gap-2 bg-[#0A192F]/50 rounded-full px-3 py-2 border border-gray-700">
              <Globe size={16} className="text-[#64FFDA]" />
              <button
                onClick={() => setLanguage('id')}
                className={`px-2 py-1 rounded-full text-sm transition-all ${
                  language === 'id'
                    ? 'bg-[#64FFDA] text-[#0A192F]'
                    : 'text-gray-400 hover:text-[#64FFDA]'
                }`}
              >
                ID
              </button>
              <button
                onClick={() => setLanguage('en')}
                className={`px-2 py-1 rounded-full text-sm transition-all ${
                  language === 'en'
                    ? 'bg-[#64FFDA] text-[#0A192F]'
                    : 'text-gray-400 hover:text-[#64FFDA]'
                }`}
              >
                EN
              </button>
            </div>
            
            <Link to="/contact">
              <Button className="bg-transparent border-2 border-[#64FFDA] text-[#64FFDA] hover:bg-[#64FFDA] hover:text-[#0A192F] transition-all">
                {t('nav.startProject')}
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-white"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-700">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`block py-3 ${
                  location.pathname === link.path
                    ? 'text-[#64FFDA]'
                    : 'text-gray-300'
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {link.name}
              </Link>
            ))}
            
            {/* Mobile Language Switcher */}
            <div className="flex items-center gap-2 py-3">
              <Globe size={16} className="text-[#64FFDA]" />
              <button
                onClick={() => setLanguage('id')}
                className={`px-3 py-1 rounded-full text-sm transition-all ${
                  language === 'id'
                    ? 'bg-[#64FFDA] text-[#0A192F]'
                    : 'text-gray-400 hover:text-[#64FFDA]'
                }`}
              >
                ID
              </button>
              <button
                onClick={() => setLanguage('en')}
                className={`px-3 py-1 rounded-full text-sm transition-all ${
                  language === 'en'
                    ? 'bg-[#64FFDA] text-[#0A192F]'
                    : 'text-gray-400 hover:text-[#64FFDA]'
                }`}
              >
                EN
              </button>
            </div>
            
            <Link to="/contact" onClick={() => setIsMobileMenuOpen(false)}>
              <Button className="w-full mt-4 bg-transparent border-2 border-[#64FFDA] text-[#64FFDA] hover:bg-[#64FFDA] hover:text-[#0A192F]">
                {t('nav.startProject')}
              </Button>
            </Link>
          </div>
        )}
      </div>
    </nav>
  );
}