import { motion } from 'motion/react';
import { Code2, Palette, Zap, Users, TrendingUp, Shield } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export default function WhyUsSection() {
  const { t, language } = useLanguage();
  
  const reasons = [
    {
      icon: Code2,
      title: 'Code Quality',
      description: 'Kode yang clean, scalable, dan maintainable dengan best practices dan testing',
      descriptionEn: 'Clean, scalable, and maintainable code with best practices and testing',
    },
    {
      icon: Palette,
      title: 'Design Excellence',
      description: 'Desain yang tidak hanya indah, tapi juga user-friendly dan conversion-focused',
      descriptionEn: 'Design that is not only beautiful, but also user-friendly and conversion-focused',
    },
    {
      icon: Zap,
      title: 'Fast Performance',
      description: 'Website yang super cepat dengan optimasi performa dan Core Web Vitals yang excellent',
      descriptionEn: 'Super fast websites with performance optimization and excellent Core Web Vitals',
    },
    {
      icon: Users,
      title: 'Collaborative Process',
      description: 'Komunikasi yang transparan dan kolaboratif dari discovery hingga launch',
      descriptionEn: 'Transparent and collaborative communication from discovery to launch',
    },
    {
      icon: TrendingUp,
      title: 'SEO Optimized',
      description: 'Website yang dibangun dengan SEO best practices untuk visibility yang maksimal',
      descriptionEn: 'Websites built with SEO best practices for maximum visibility',
    },
    {
      icon: Shield,
      title: 'Ongoing Support',
      description: 'Dukungan maintenance dan technical support setelah website live',
      descriptionEn: 'Maintenance and technical support after website launch',
    },
  ];
  
  return (
    <section className="py-24 bg-[#0A192F]">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-white mb-4">{t('whyus.title')}</h2>
          <p className="text-gray-400 text-xl max-w-2xl mx-auto">
            {t('whyus.subtitle')}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reasons.map((reason, index) => (
            <motion.div
              key={reason.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group"
            >
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-[#64FFDA]/10 rounded-lg flex items-center justify-center group-hover:bg-[#64FFDA]/20 transition-colors">
                    <reason.icon className="text-[#64FFDA]" size={24} />
                  </div>
                </div>
                <div>
                  <h3 className="text-white mb-2">{reason.title}</h3>
                  <p className="text-gray-400">
                    {language === 'id' ? reason.description : reason.descriptionEn}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
