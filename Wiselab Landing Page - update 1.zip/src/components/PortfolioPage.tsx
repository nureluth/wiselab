import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { ExternalLink } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useLanguage } from '../contexts/LanguageContext';
import bgImage from 'figma:asset/e25ad44609a4a09cb46cb699c8fbe72bfc05c657.png';
import { portfolioData } from '../data/portfolioData';

export default function PortfolioPage() {
  const { t, language } = useLanguage();
  
  const categories = language === 'id' 
    ? ['Semua', 'E-Commerce', 'Health & Fitness', 'Travel & Tourism', 'Food & Beverage', 'Architecture', 'Digital Marketing', 'Education', 'SaaS', 'Real Estate', 'Personal Portfolio', 'Event Planning', 'Photography']
    : ['All', 'E-Commerce', 'Health & Fitness', 'Travel & Tourism', 'Food & Beverage', 'Architecture', 'Digital Marketing', 'Education', 'SaaS', 'Real Estate', 'Personal Portfolio', 'Event Planning', 'Photography'];
  
  const [selectedCategory, setSelectedCategory] = useState(categories[0]);
  
  // Update selected category when language changes
  useEffect(() => {
    setSelectedCategory(categories[0]);
  }, [language]);

  const filteredProjects =
    selectedCategory === categories[0]
      ? portfolioData
      : portfolioData.filter((project) => project.category === selectedCategory);

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section
        className="relative py-24 overflow-hidden"
        style={{
          backgroundImage: `url(${bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-[#0A192F]/90" />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-white mb-6">{t('productsPage.title')}</h1>
            <p className="text-gray-300 text-xl">
              {t('productsPage.subtitle')}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filter Section */}
      <section className="py-12 bg-[#0A192F] border-b border-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex flex-wrap justify-center gap-3"
          >
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-2 rounded-full transition-all ${
                  selectedCategory === category
                    ? 'bg-[#64FFDA] text-[#0A192F]'
                    : 'bg-[#112240] text-gray-300 hover:bg-[#112240]/70 border border-gray-700'
                }`}
              >
                {category}
              </button>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="py-24 bg-[#020c1b]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((project, index) => (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="group relative overflow-hidden bg-[#112240] border-gray-700 hover:border-[#64FFDA]/50 transition-all h-full">
                  <div className="aspect-video overflow-hidden">
                    <ImageWithFallback
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <CardContent className="p-6">
                    <Badge className="bg-[#64FFDA]/20 text-[#64FFDA] border-[#64FFDA]/30 mb-3">
                      {project.category}
                    </Badge>
                    <h3 className="text-white mb-2">{project.title}</h3>
                    <p className="text-gray-400 mb-4">{project.description}</p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.tags.map((tag) => (
                        <span
                          key={tag}
                          className="text-xs px-3 py-1 bg-[#0A192F] text-gray-400 rounded-full"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                    <Link 
                      to={`/portfolio/${project.id}`}
                      className="text-[#64FFDA] flex items-center gap-2 group-hover:gap-3 transition-all"
                    >
                      {t('portfolio.viewDetail')}
                      <ExternalLink size={16} />
                    </Link>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
