import { motion } from 'motion/react';
import { Palette, Layers, Smartphone, Code2, Rocket, Gauge, Search, Zap, Wrench, HeadphonesIcon, Server, Cloud, Lock, Database } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { useLanguage } from '../contexts/LanguageContext';
import bgImage from 'figma:asset/e25ad44609a4a09cb46cb699c8fbe72bfc05c657.png';

export default function ServicesPage() {
  const { t, language } = useLanguage();
  
  const services = [
    {
      title: 'UI/UX Design',
      description: language === 'id' 
        ? 'Kami menciptakan desain website yang intuitif, menarik, dan berpusat pada pengguna untuk memberikan pengalaman digital terbaik.'
        : 'We create intuitive, engaging, and user-centric website designs to deliver the best digital experience.',
      icon: Palette,
      subServices: [
        {
          icon: Layers,
          title: 'User Research & Analysis',
          description: language === 'id'
            ? 'Analisis mendalam tentang kebutuhan pengguna dan kompetitor untuk menciptakan solusi yang tepat sasaran.'
            : 'In-depth analysis of user needs and competitors to create targeted solutions.',
        },
        {
          icon: Layers,
          title: 'Wireframing & Mockups',
          description: language === 'id'
            ? 'Visualisasi struktur dan layout website sebelum masuk ke tahap design visual.'
            : 'Visualizing website structure and layout before moving to visual design phase.',
        },
        {
          icon: Smartphone,
          title: 'Visual Design',
          description: language === 'id'
            ? 'Desain antarmuka yang estetis dengan sistem desain yang konsisten dan modern.'
            : 'Aesthetic interface design with consistent and modern design systems.',
        },
        {
          icon: Layers,
          title: 'Interactive Prototypes',
          description: language === 'id'
            ? 'Prototype interaktif untuk testing dan validasi sebelum development.'
            : 'Interactive prototypes for testing and validation before development.',
        },
      ],
    },
    {
      title: 'Web Development',
      description: language === 'id'
        ? 'Membangun website yang robust, scalable, dan performant dengan teknologi modern dan best practices.'
        : 'Building robust, scalable, and performant websites with modern technology and best practices.',
      icon: Code2,
      subServices: [
        {
          icon: Code2,
          title: 'Frontend Development',
          description: language === 'id'
            ? 'Pengembangan frontend dengan React, Next.js, Vue.js dan framework modern lainnya.'
            : 'Frontend development with React, Next.js, Vue.js and other modern frameworks.',
        },
        {
          icon: Code2,
          title: 'Backend Development',
          description: language === 'id'
            ? 'Sistem backend yang solid dengan Node.js, API yang aman dan database yang efisien.'
            : 'Solid backend systems with Node.js, secure APIs and efficient databases.',
        },
        {
          icon: Smartphone,
          title: 'Responsive Design',
          description: language === 'id'
            ? 'Website yang perfect di semua device - desktop, tablet, dan mobile.'
            : 'Perfect websites across all devices - desktop, tablet, and mobile.',
        },
        {
          icon: Rocket,
          title: 'CMS Integration',
          description: language === 'id'
            ? 'Integrasi dengan CMS seperti WordPress, Sanity, atau Contentful untuk management konten yang mudah.'
            : 'Integration with CMS like WordPress, Sanity, or Contentful for easy content management.',
        },
      ],
    },
    {
      title: 'Website Optimization',
      description: language === 'id'
        ? 'Optimasi website untuk performa maksimal, SEO yang baik, dan user experience yang superior.'
        : 'Website optimization for maximum performance, good SEO, and superior user experience.',
      icon: Gauge,
      subServices: [
        {
          icon: Zap,
          title: 'Performance Optimization',
          description: language === 'id'
            ? 'Optimasi kecepatan loading, code splitting, lazy loading, dan caching strategy.'
            : 'Loading speed optimization, code splitting, lazy loading, and caching strategy.',
        },
        {
          icon: Search,
          title: 'SEO Optimization',
          description: language === 'id'
            ? 'Optimasi SEO on-page dan technical SEO untuk ranking yang lebih baik di search engine.'
            : 'On-page SEO and technical SEO optimization for better search engine rankings.',
        },
        {
          icon: Gauge,
          title: 'Core Web Vitals',
          description: language === 'id'
            ? 'Optimasi metrik performa Google untuk ranking dan user experience yang optimal.'
            : 'Google performance metrics optimization for optimal ranking and user experience.',
        },
        {
          icon: Smartphone,
          title: 'Mobile Optimization',
          description: language === 'id'
            ? 'Optimasi khusus untuk mobile devices dengan mobile-first approach.'
            : 'Special optimization for mobile devices with mobile-first approach.',
        },
      ],
    },
    {
      title: 'Maintenance & Support',
      description: language === 'id'
        ? 'Dukungan berkelanjutan untuk memastikan website Anda selalu up-to-date, aman, dan berjalan dengan baik.'
        : 'Ongoing support to ensure your website is always up-to-date, secure, and running smoothly.',
      icon: Wrench,
      subServices: [
        {
          icon: Rocket,
          title: 'Regular Updates',
          description: language === 'id'
            ? 'Update berkala untuk dependencies, security patches, dan feature improvements.'
            : 'Regular updates for dependencies, security patches, and feature improvements.',
        },
        {
          icon: Wrench,
          title: 'Bug Fixes',
          description: language === 'id'
            ? 'Perbaikan bug dan issue yang muncul dengan response time yang cepat.'
            : 'Bug fixes and issue resolution with fast response time.',
        },
        {
          icon: Zap,
          title: 'Performance Monitoring',
          description: language === 'id'
            ? 'Monitoring performa website secara real-time dan optimization berkelanjutan.'
            : 'Real-time website performance monitoring and continuous optimization.',
        },
        {
          icon: HeadphonesIcon,
          title: 'Technical Support',
          description: language === 'id'
            ? 'Dukungan teknis untuk membantu mengatasi masalah dan pertanyaan terkait website.'
            : 'Technical support to help resolve website-related issues and questions.',
        },
      ],
    },
    {
      title: 'Hosting',
      description: language === 'id'
        ? 'Solusi hosting yang handal dan aman untuk menjaga website Anda tetap online 24/7.'
        : 'Reliable and secure hosting solutions to keep your website online 24/7.',
      icon: Server,
      badge: language === 'id' ? 'Segera Hadir' : 'Coming Soon',
      subServices: [
        {
          icon: Cloud,
          title: 'Cloud Hosting',
          description: language === 'id'
            ? 'Hosting berbasis cloud yang scalable dan reliable untuk performa optimal.'
            : 'Scalable and reliable cloud-based hosting for optimal performance.',
        },
        {
          icon: Lock,
          title: 'SSL Certificate',
          description: language === 'id'
            ? 'Sertifikat keamanan SSL untuk melindungi data dan meningkatkan kepercayaan.'
            : 'SSL security certificate to protect data and increase trust.',
        },
        {
          icon: Database,
          title: 'Backup & Recovery',
          description: language === 'id'
            ? 'Sistem backup otomatis dan recovery untuk melindungi data website Anda.'
            : 'Automated backup and recovery system to protect your website data.',
        },
        {
          icon: Server,
          title: 'Server Monitoring',
          description: language === 'id'
            ? 'Monitoring server 24/7 untuk memastikan uptime maksimal.'
            : '24/7 server monitoring to ensure maximum uptime.',
        },
      ],
    },
  ];

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section
        className="relative py-24 overflow-hidden"
        style={{
          backgroundImage: `url(${bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-[#0A192F]/90" />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-white mb-6">{t('servicesPage.title')}</h1>
            <p className="text-gray-300 text-xl">
              {t('servicesPage.subtitle')}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-24 bg-[#0A192F]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-24">
            {services.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <div className="text-center mb-12">
                  <div className="flex items-center justify-center gap-4 mb-4">
                    <div className="p-4 bg-[#64FFDA]/10 rounded-lg">
                      <service.icon className="text-[#64FFDA]" size={40} />
                    </div>
                    {service.badge && (
                      <Badge className="bg-[#64FFDA]/20 text-[#64FFDA] border-[#64FFDA]/30">
                        {service.badge}
                      </Badge>
                    )}
                  </div>
                  <h2 className="text-white mb-4">{service.title}</h2>
                  <p className="text-gray-400 text-lg max-w-3xl mx-auto">
                    {service.description}
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {service.subServices.map((subService, subIndex) => (
                    <motion.div
                      key={subService.title}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.6, delay: subIndex * 0.1 }}
                    >
                      <Card className="bg-[#112240] border-gray-700 hover:border-[#64FFDA]/50 transition-all h-full">
                        <CardContent className="p-6">
                          <div className="flex items-start gap-4">
                            <div className="p-3 bg-[#64FFDA]/10 rounded-lg flex-shrink-0">
                              <subService.icon className="text-[#64FFDA]" size={24} />
                            </div>
                            <div>
                              <h3 className="text-white mb-2">{subService.title}</h3>
                              <p className="text-gray-400">{subService.description}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-[#020c1b]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h2 className="text-white mb-6">
              {language === 'id' ? 'Siap Memulai Proyek Anda?' : 'Ready to Start Your Project?'}
            </h2>
            <p className="text-gray-400 text-xl mb-8 max-w-2xl mx-auto">
              {language === 'id'
                ? 'Mari diskusikan kebutuhan Anda dan ciptakan solusi digital yang sempurna untuk bisnis Anda'
                : "Let's discuss your needs and create the perfect digital solution for your business"}
            </p>
            <a
              href="/contact"
              className="inline-flex items-center px-8 py-4 bg-[#64FFDA] text-[#0A192F] rounded-lg hover:bg-[#64FFDA]/90 transition-colors"
            >
              {language === 'id' ? 'Hubungi Kami' : 'Contact Us'}
            </a>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
