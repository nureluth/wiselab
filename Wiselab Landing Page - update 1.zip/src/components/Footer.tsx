import { Link } from 'react-router-dom';
import { Instagram, Mail, MapPin } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import logoImage from 'figma:asset/367410809346896deab2407afda0833b661a4148.png';

export default function Footer() {
  const { t } = useLanguage();
  return (
    <footer className="bg-[#020c1b] border-t border-gray-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <img src={logoImage} alt="Wiselab Logo" className="h-10 w-10" />
              <span className="text-white text-2xl">Wiselab</span>
            </div>
            <p className="text-gray-400 mb-4">
              {t('footer.tagline')}
            </p>
            <div className="flex gap-4">
              <a
                href="https://instagram.com/wiselab.co"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-[#64FFDA] transition-colors"
              >
                <Instagram size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white mb-4">{t('footer.navigation')}</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-400 hover:text-[#64FFDA] transition-colors">
                  {t('nav.home')}
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-gray-400 hover:text-[#64FFDA] transition-colors">
                  {t('nav.services')}
                </Link>
              </li>
              <li>
                <Link to="/portfolio" className="text-gray-400 hover:text-[#64FFDA] transition-colors">
                  {t('nav.products')}
                </Link>
              </li>
              <li>
                <Link to="/join-freelance" className="text-gray-400 hover:text-[#64FFDA] transition-colors">
                  {t('nav.joinFreelance')}
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-400 hover:text-[#64FFDA] transition-colors">
                  {t('nav.contact')}
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-white mb-4">{t('footer.services')}</h3>
            <ul className="space-y-2">
              <li className="text-gray-400">{t('service.uiux.title')}</li>
              <li className="text-gray-400">{t('service.webdev.title')}</li>
              <li className="text-gray-400">{t('service.optimization.title')}</li>
              <li className="text-gray-400">{t('service.maintenance.title')}</li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-white mb-4">{t('footer.contact')}</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-2 text-gray-400">
                <Mail size={18} className="mt-1 flex-shrink-0" />
                <a href="mailto:wiselabco@gmail.com" className="hover:text-[#64FFDA] transition-colors">
                  wiselabco@gmail.com
                </a>
              </li>
              <li className="flex items-start gap-2 text-gray-400">
                <MapPin size={18} className="mt-1 flex-shrink-0" />
                <span>Amega Crown Residence, Sidoarjo, Indonesia</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Wiselab. {t('footer.rights')}</p>
        </div>
      </div>
    </footer>
  );
}