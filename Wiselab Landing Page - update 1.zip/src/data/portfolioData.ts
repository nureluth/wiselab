export interface Portfolio {
  id: string;
  title: string;
  category: string;
  description: string;
  image: string;
  tags: string[];
  isSample?: boolean;
}

export const portfolioData: Portfolio[] = [
  // Sample Websites - Interactive Demos
  {
    id: 'fashion-store',
    title: 'LUXE Fashion Store',
    category: 'E-Commerce',
    description: 'Modern e-commerce website untuk fashion brand premium dengan shopping cart, product showcase, dan smooth animations',
    image: 'https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?w=1080',
    tags: ['E-Commerce', 'Fashion', 'React', 'Tailwind CSS'],
    isSample: true,
  },
  {
    id: 'fitness-studio',
    title: 'FITZONE Fitness Studio',
    category: 'Health & Fitness',
    description: 'Website gym & fitness studio dengan class schedule, trainer profiles, membership plans, dan booking system',
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1080',
    tags: ['Fitness', 'Booking', 'Membership', 'Responsive'],
    isSample: true,
  },
  {
    id: 'travel-agency',
    title: 'WanderLust Travel Agency',
    category: 'Travel & Tourism',
    description: 'Travel agency website dengan destination showcase, tour packages, search functionality, dan booking features',
    image: 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=1080',
    tags: ['Travel', 'Tourism', 'Booking', 'Search'],
    isSample: true,
  },
  {
    id: 'coffee-shop',
    title: 'Brew Haven Coffee Shop',
    category: 'Food & Beverage',
    description: 'Cozy coffee shop website dengan digital menu, location info, story section, dan online ordering',
    image: 'https://images.unsplash.com/photo-1521017432531-fbd92d768814?w=1080',
    tags: ['Coffee', 'Menu', 'Restaurant', 'Online Order'],
    isSample: true,
  },
  {
    id: 'architect-studio',
    title: 'ARCVISION Architecture',
    category: 'Architecture',
    description: 'Minimalist architecture studio website dengan project showcase, services, dan portfolio yang elegant',
    image: 'https://images.unsplash.com/photo-1519662978799-2f05096d3636?w=1080',
    tags: ['Architecture', 'Portfolio', 'Minimalist', 'Design'],
    isSample: true,
  },
  {
    id: 'digital-agency',
    title: 'PIXEL Digital Agency',
    category: 'Digital Marketing',
    description: 'Vibrant digital marketing agency website dengan bold design, service showcase, dan conversion-focused layout',
    image: 'https://images.unsplash.com/photo-1557838923-2985c318be48?w=1080',
    tags: ['Marketing', 'Agency', 'Gradient', 'Modern'],
    isSample: true,
  },
  {
    id: 'online-course',
    title: 'SkillUp Online Course',
    category: 'Education',
    description: 'E-learning platform dengan course catalog, enrollment system, instructor profiles, dan student dashboard',
    image: 'https://images.unsplash.com/photo-1610484826967-09c5720778c7?w=1080',
    tags: ['Education', 'E-Learning', 'Courses', 'LMS'],
    isSample: true,
  },
  {
    id: 'food-delivery',
    title: 'FoodHub Delivery',
    category: 'Food Delivery',
    description: 'Food delivery platform dengan restaurant listings, search, order tracking, dan mobile-first design',
    image: 'https://images.unsplash.com/photo-1617347454431-f49d7ff5c3b1?w=1080',
    tags: ['Food', 'Delivery', 'Mobile-First', 'Search'],
    isSample: true,
  },
  {
    id: 'music-studio',
    title: 'SoundLab Recording Studio',
    category: 'Music & Audio',
    description: 'Professional recording studio website dengan service showcase, portfolio, booking system, dan dark theme',
    image: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=1080',
    tags: ['Music', 'Studio', 'Dark Theme', 'Booking'],
    isSample: true,
  },
  {
    id: 'saas-landing',
    title: 'DataFlow SaaS Platform',
    category: 'SaaS',
    description: 'Clean SaaS landing page dengan feature highlights, pricing tiers, testimonials, dan high conversion design',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1080',
    tags: ['SaaS', 'Landing Page', 'Pricing', 'B2B'],
    isSample: true,
  },
  {
    id: 'real-estate',
    title: 'EstateView Property',
    category: 'Real Estate',
    description: 'Real estate website dengan property listings, advanced search & filters, property details, dan contact forms',
    image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=1080',
    tags: ['Real Estate', 'Property', 'Search', 'Listings'],
    isSample: true,
  },
  {
    id: 'creative-portfolio',
    title: 'Alex Morgan Portfolio',
    category: 'Personal Portfolio',
    description: 'Creative portfolio website untuk designer & developer dengan work showcase, minimal dark design, dan smooth animations',
    image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=1080',
    tags: ['Portfolio', 'Creative', 'Dark', 'Personal'],
    isSample: true,
  },
  {
    id: 'event-management',
    title: 'EventPro Management',
    category: 'Event Planning',
    description: 'Event management website dengan upcoming events, registration system, statistics, dan vibrant gradient design',
    image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=1080',
    tags: ['Events', 'Management', 'Registration', 'Gradient'],
    isSample: true,
  },
  {
    id: 'photography-studio',
    title: 'LENS Photography',
    category: 'Photography',
    description: 'Photography studio website dengan stunning gallery, service categories, booking system, dan image-focused design',
    image: 'https://images.unsplash.com/photo-1452587925148-ce544e77e70d?w=1080',
    tags: ['Photography', 'Gallery', 'Portfolio', 'Visual'],
    isSample: true,
  },
];
