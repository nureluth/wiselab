import { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'id' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations = {
  id: {
    // Navbar
    'nav.home': 'Beranda',
    'nav.services': 'Layanan',
    'nav.products': 'Produk Kami',
    'nav.joinFreelance': 'Join Freelance',
    'nav.contact': 'Kontak',
    'nav.startProject': 'Mulai Proyek',
    
    // Hero Section
    'hero.title': 'Crafting Digital Excellence',
    'hero.subtitle': 'from Concept to Code',
    'hero.heading': 'Website yang Powerful, Dimulai dari Desain yang Sempurna',
    'hero.description': 'Kami menciptakan website yang tidak hanya terlihat stunning, tapi juga bekerja dengan optimal. Dari UI/UX design hingga development yang clean dan scalable.',
    'hero.getStarted': 'Mulai Proyek Anda',
    'hero.viewServices': 'Lihat Layanan Kami',
    'hero.viewProducts': 'Lihat Produk',
    
    // Stats
    'stats.projects': 'Proyek Selesai',
    'stats.clients': 'Klien Puas',
    'stats.experience': 'Tahun Pengalaman',
    
    // Services Section
    'services.title': 'Layanan Kami',
    'services.subtitle': 'Solusi digital komprehensif untuk menghadirkan produk terbaik bagi bisnis Anda',
    'services.viewAll': 'Lihat Semua Layanan',
    
    // Service Items
    'service.uiux.title': 'Desain UI/UX',
    'service.uiux.desc': 'Menciptakan pengalaman pengguna yang intuitif dan antarmuka yang menarik untuk meningkatkan engagement.',
    'service.webdev.title': 'Pengembangan Web',
    'service.webdev.desc': 'Membangun website modern, responsif, dan scalable menggunakan teknologi terkini.',
    'service.optimization.title': 'Optimasi Website',
    'service.optimization.desc': 'Meningkatkan performa, kecepatan, dan SEO website Anda untuk hasil maksimal.',
    'service.maintenance.title': 'Maintenance & Support',
    'service.maintenance.desc': 'Dukungan berkelanjutan dan pemeliharaan rutin untuk memastikan website Anda selalu optimal.',
    'service.hosting.title': 'Hosting & Domain',
    'service.hosting.desc': 'Solusi hosting yang cepat, aman, dan reliable untuk website Anda.',
    'service.comingSoon': 'Segera Hadir',
    
    // Products Section
    'products.title': 'Produk Unggulan',
    'products.subtitle': 'Beberapa produk website terbaik yang dapat menjadi solusi untuk bisnis Anda',
    'products.viewAll': 'Lihat Semua Produk',
    'products.viewDemo': 'Lihat Demo',
    
    // Portfolio Section
    'portfolio.title': 'Produk Unggulan',
    'portfolio.description': 'Beberapa produk website terbaik yang dapat menjadi solusi untuk bisnis Anda',
    'portfolio.viewDetail': 'Lihat Detail',
    'portfolio.viewAllProjects': 'Lihat Semua Proyek',
    
    // Why Us Section
    'whyus.title': 'Mengapa Memilih Wiselab?',
    'whyus.subtitle': 'Keunggulan yang membuat kami menjadi partner terpercaya untuk transformasi digital Anda',
    'whyus.innovation.title': 'Inovatif',
    'whyus.innovation.desc': 'Menggunakan teknologi terkini untuk solusi yang modern',
    'whyus.precision.title': 'Presisi',
    'whyus.precision.desc': 'Detail-oriented dalam setiap aspek pengembangan',
    'whyus.trust.title': 'Terpercaya',
    'whyus.trust.desc': 'Track record solid dengan klien yang puas',
    'whyus.support.title': 'Support 24/7',
    'whyus.support.desc': 'Tim kami siap membantu kapan saja Anda butuhkan',
    
    // CTA Section
    'cta.title': 'Siap Memulai Proyek Anda?',
    'cta.subtitle': 'Mari wujudkan ide digital Anda bersama tim expert kami',
    'cta.button': 'Hubungi Kami',
    
    // Footer
    'footer.tagline': 'Crafting Digital Excellence, from Concept to Code.',
    'footer.navigation': 'Navigasi',
    'footer.services': 'Layanan',
    'footer.contact': 'Kontak',
    'footer.rights': 'Hak Cipta Dilindungi.',
    
    // Services Page
    'servicesPage.title': 'Layanan Profesional Kami',
    'servicesPage.subtitle': 'Solusi Web Design & Development yang Komprehensif untuk Kesuksesan Bisnis Anda',
    'servicesPage.learnMore': 'Pelajari Lebih Lanjut',
    
    // Products Page
    'productsPage.title': 'Produk Kami',
    'productsPage.subtitle': 'Jelajahi koleksi produk website berkualitas tinggi yang kami tawarkan sebagai solusi siap pakai untuk bisnis Anda',
    'productsPage.all': 'Semua',
    'productsPage.ecommerce': 'E-Commerce',
    'productsPage.corporate': 'Corporate',
    'productsPage.creative': 'Creative',
    
    // Contact Page
    'contactPage.title': 'Mari Berkolaborasi',
    'contactPage.subtitle': 'Hubungi kami untuk mendiskusikan proyek digital Anda',
    'contactPage.getInTouch': 'Hubungi Kami',
    'contactPage.getInTouchDesc': 'Isi formulir di bawah atau hubungi kami langsung',
    'contactPage.name': 'Nama Lengkap',
    'contactPage.email': 'Email',
    'contactPage.phone': 'Nomor Telepon',
    'contactPage.company': 'Nama Perusahaan',
    'contactPage.service': 'Layanan yang Diminati',
    'contactPage.message': 'Pesan Anda',
    'contactPage.send': 'Kirim Pesan',
    'contactPage.office': 'Kantor Kami',
    'contactPage.businessHours': 'Jam Kerja',
    'contactPage.monFri': 'Senin - Jumat',
    'contactPage.saturday': 'Sabtu',
    'contactPage.sunday': 'Minggu',
    'contactPage.closed': 'Tutup',
    
    // Join Freelance Page
    'joinFreelance.title': 'Bergabung dengan Network Wiselab',
    'joinFreelance.subtitle': 'Jadilah bagian dari tim freelancer berbakat kami',
    'joinFreelance.why': 'Mengapa Bergabung?',
    'joinFreelance.flexible.title': 'Fleksibilitas',
    'joinFreelance.flexible.desc': 'Kerja dari mana saja dengan jadwal yang fleksibel',
    'joinFreelance.projects.title': 'Proyek Berkualitas',
    'joinFreelance.projects.desc': 'Akses ke proyek-proyek menarik dari klien terpercaya',
    'joinFreelance.payment.title': 'Pembayaran Kompetitif',
    'joinFreelance.payment.desc': 'Dapatkan bayaran yang sesuai dengan keahlian Anda',
    'joinFreelance.growth.title': 'Pengembangan Karir',
    'joinFreelance.growth.desc': 'Kesempatan untuk belajar dan berkembang',
    'joinFreelance.apply': 'Daftar Sekarang',
    'joinFreelance.fullName': 'Nama Lengkap',
    'joinFreelance.portfolio': 'Link Portfolio',
    'joinFreelance.expertise': 'Keahlian Utama',
    'joinFreelance.experience': 'Pengalaman (tahun)',
    'joinFreelance.about': 'Tentang Anda',
    'joinFreelance.submit': 'Kirim Lamaran',
    
    // Common
    'common.backToProducts': 'Back to Our Products',
    'common.readMore': 'Read More',
  },
  en: {
    // Navbar
    'nav.home': 'Home',
    'nav.services': 'Services',
    'nav.products': 'Our Products',
    'nav.joinFreelance': 'Join Freelance',
    'nav.contact': 'Contact',
    'nav.startProject': 'Start Project',
    
    // Hero Section
    'hero.title': 'Crafting Digital Excellence',
    'hero.subtitle': 'from Concept to Code',
    'hero.heading': 'Powerful Websites, Starting with Perfect Design',
    'hero.description': 'We create websites that not only look stunning but also work optimally. From UI/UX design to clean and scalable development.',
    'hero.getStarted': 'Start Your Project',
    'hero.viewServices': 'View Our Services',
    'hero.viewProducts': 'View Products',
    
    // Stats
    'stats.projects': 'Projects Completed',
    'stats.clients': 'Happy Clients',
    'stats.experience': 'Years Experience',
    
    // Services Section
    'services.title': 'Our Services',
    'services.subtitle': 'Complete solutions for your business digital needs',
    'services.viewAll': 'View All Services',
    
    // Service Items
    'service.uiux.title': 'UI/UX Design',
    'service.uiux.desc': 'Creating intuitive user experiences and engaging interfaces to boost engagement.',
    'service.webdev.title': 'Web Development',
    'service.webdev.desc': 'Building modern, responsive, and scalable websites using cutting-edge technology.',
    'service.optimization.title': 'Website Optimization',
    'service.optimization.desc': 'Improving performance, speed, and SEO of your website for maximum results.',
    'service.maintenance.title': 'Maintenance & Support',
    'service.maintenance.desc': 'Ongoing support and regular maintenance to ensure your website is always optimal.',
    'service.hosting.title': 'Hosting & Domain',
    'service.hosting.desc': 'Fast, secure, and reliable hosting solutions for your website.',
    'service.comingSoon': 'Coming Soon',
    
    // Products Section
    'products.title': 'Featured Products',
    'products.subtitle': 'Some of the best website products that can be solutions for your business',
    'products.viewAll': 'View All Products',
    'products.viewDemo': 'View Demo',
    
    // Portfolio Section
    'portfolio.title': 'Featured Products',
    'portfolio.description': 'Some of the best website products that can be solutions for your business',
    'portfolio.viewDetail': 'View Detail',
    'portfolio.viewAllProjects': 'View All Projects',
    
    // Why Us Section
    'whyus.title': 'Why Choose Wiselab?',
    'whyus.subtitle': 'Our advantages that make us a trusted partner for your digital transformation',
    'whyus.innovation.title': 'Innovative',
    'whyus.innovation.desc': 'Using the latest technology for modern solutions',
    'whyus.precision.title': 'Precision',
    'whyus.precision.desc': 'Detail-oriented in every aspect of development',
    'whyus.trust.title': 'Trustworthy',
    'whyus.trust.desc': 'Solid track record with satisfied clients',
    'whyus.support.title': '24/7 Support',
    'whyus.support.desc': 'Our team is ready to help anytime you need',
    
    // CTA Section
    'cta.title': 'Ready to Start Your Project?',
    'cta.subtitle': "Let's bring your digital ideas to life with our expert team",
    'cta.button': 'Contact Us',
    
    // Footer
    'footer.tagline': 'Crafting Digital Excellence, from Concept to Code.',
    'footer.navigation': 'Navigation',
    'footer.services': 'Services',
    'footer.contact': 'Contact',
    'footer.rights': 'All Rights Reserved.',
    
    // Services Page
    'servicesPage.title': 'Our Professional Services',
    'servicesPage.subtitle': 'Comprehensive Web Design & Development Solutions for Your Business Success',
    'servicesPage.learnMore': 'Learn More',
    
    // Products Page
    'productsPage.title': 'Our Products',
    'productsPage.subtitle': 'Explore our collection of high-quality website products offered as ready-to-use solutions for your business',
    'productsPage.all': 'All',
    'productsPage.ecommerce': 'E-Commerce',
    'productsPage.corporate': 'Corporate',
    'productsPage.creative': 'Creative',
    
    // Contact Page
    'contactPage.title': "Let's Collaborate",
    'contactPage.subtitle': 'Contact us to discuss your digital project',
    'contactPage.getInTouch': 'Get In Touch',
    'contactPage.getInTouchDesc': 'Fill out the form below or contact us directly',
    'contactPage.name': 'Full Name',
    'contactPage.email': 'Email',
    'contactPage.phone': 'Phone Number',
    'contactPage.company': 'Company Name',
    'contactPage.service': 'Service of Interest',
    'contactPage.message': 'Your Message',
    'contactPage.send': 'Send Message',
    'contactPage.office': 'Our Office',
    'contactPage.businessHours': 'Business Hours',
    'contactPage.monFri': 'Monday - Friday',
    'contactPage.saturday': 'Saturday',
    'contactPage.sunday': 'Sunday',
    'contactPage.closed': 'Closed',
    
    // Join Freelance Page
    'joinFreelance.title': 'Join Wiselab Network',
    'joinFreelance.subtitle': 'Be part of our talented freelancer team',
    'joinFreelance.why': 'Why Join?',
    'joinFreelance.flexible.title': 'Flexibility',
    'joinFreelance.flexible.desc': 'Work from anywhere with a flexible schedule',
    'joinFreelance.projects.title': 'Quality Projects',
    'joinFreelance.projects.desc': 'Access to exciting projects from trusted clients',
    'joinFreelance.payment.title': 'Competitive Payment',
    'joinFreelance.payment.desc': 'Get paid according to your expertise',
    'joinFreelance.growth.title': 'Career Growth',
    'joinFreelance.growth.desc': 'Opportunities to learn and grow',
    'joinFreelance.apply': 'Apply Now',
    'joinFreelance.fullName': 'Full Name',
    'joinFreelance.portfolio': 'Portfolio Link',
    'joinFreelance.expertise': 'Main Expertise',
    'joinFreelance.experience': 'Experience (years)',
    'joinFreelance.about': 'About You',
    'joinFreelance.submit': 'Submit Application',
    
    // Common
    'common.backToProducts': 'Back to Our Products',
    'common.readMore': 'Read More',
  }
};

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('id');

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}