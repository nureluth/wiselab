# Language Implementation Guide

## ✅ Status Implementasi

### Sudah Selesai:
1. **LanguageContext** - Context untuk manage bahasa dan translations
2. **Navbar** - Language switcher sudah ditambahkan (ID/EN toggle button dengan icon Globe)
3. **App.tsx** - LanguageProvider sudah di-wrap

### Yang Perlu Dilakukan:

Untuk setiap komponen yang memiliki text statis, ikuti pattern berikut:

## Pattern Implementasi

### 1. Import useLanguage hook
```typescript
import { useLanguage } from '../contexts/LanguageContext';
```

### 2. Gunakan hook di dalam komponen
```typescript
export default function ComponentName() {
  const { t } = useLanguage();
  
  // ... rest of component
}
```

### 3. Ganti semua text statis dengan t('key')
```typescript
// Sebelum:
<h1>Proyek Selesai</h1>

// Sesudah:
<h1>{t('stats.projects')}</h1>
```

## Translations yang Sudah Tersedia

Semua translations sudah tersedia di `/contexts/LanguageContext.tsx`. Berikut adalah key-key yang bisa digunakan:

### Navbar
- `nav.home` - Beranda / Home
- `nav.services` - Layanan / Services
- `nav.products` - Produk Kami / Our Products
- `nav.joinFreelance` - Join Freelance
- `nav.contact` - Kontak / Contact
- `nav.startProject` - Mulai Proyek / Start Project

### Hero Section
- `hero.title` - Crafting Digital Excellence
- `hero.subtitle` - from Concept to Code
- `hero.description` - Deskripsi hero
- `hero.getStarted` - Mulai Sekarang / Get Started
- `hero.viewProducts` - Lihat Produk / View Products

### Stats
- `stats.projects` - Proyek Selesai / Projects Completed
- `stats.clients` - Klien Puas / Happy Clients
- `stats.experience` - Tahun Pengalaman / Years Experience

### Services
- `services.title` - Layanan Kami / Our Services
- `services.subtitle` - Subtitle
- `services.viewAll` - Lihat Semua Layanan / View All Services
- `service.uiux.title` - Desain UI/UX / UI/UX Design
- `service.uiux.desc` - Description
- `service.webdev.title` - Pengembangan Web / Web Development
- `service.webdev.desc` - Description
- `service.optimization.title` - Optimasi Website / Website Optimization
- `service.optimization.desc` - Description
- `service.maintenance.title` - Maintenance & Support
- `service.maintenance.desc` - Description
- `service.hosting.title` - Hosting & Domain
- `service.hosting.desc` - Description
- `service.comingSoon` - Segera Hadir / Coming Soon

### Products
- `products.title` - Produk Unggulan / Featured Products
- `products.subtitle` - Subtitle
- `products.viewAll` - Lihat Semua Produk / View All Products
- `products.viewDemo` - Lihat Demo / View Demo

### Why Us
- `whyus.title` - Mengapa Memilih Wiselab? / Why Choose Wiselab?
- `whyus.subtitle` - Subtitle
- `whyus.innovation.title` - Inovatif / Innovative
- `whyus.innovation.desc` - Description
- `whyus.precision.title` - Presisi / Precision
- `whyus.precision.desc` - Description
- `whyus.trust.title` - Terpercaya / Trustworthy
- `whyus.trust.desc` - Description
- `whyus.support.title` - Support 24/7
- `whyus.support.desc` - Description

### CTA Section
- `cta.title` - Siap Memulai Proyek Anda? / Ready to Start Your Project?
- `cta.subtitle` - Subtitle
- `cta.button` - Hubungi Kami / Contact Us

### Footer
- `footer.tagline` - Crafting Digital Excellence, from Concept to Code.
- `footer.navigation` - Navigasi / Navigation
- `footer.services` - Layanan / Services
- `footer.contact` - Kontak / Contact
- `footer.rights` - Hak Cipta Dilindungi / All Rights Reserved

### Services Page
- `servicesPage.title` - Layanan Profesional Kami / Our Professional Services
- `servicesPage.subtitle` - Subtitle
- `servicesPage.learnMore` - Pelajari Lebih Lanjut / Learn More

### Products Page
- `productsPage.title` - Produk Kami / Our Products
- `productsPage.subtitle` - Subtitle
- `productsPage.all` - Semua / All
- `productsPage.ecommerce` - E-Commerce
- `productsPage.corporate` - Corporate
- `productsPage.creative` - Creative

### Contact Page
- `contactPage.title` - Mari Berkolaborasi / Let's Collaborate
- `contactPage.subtitle` - Subtitle
- `contactPage.getInTouch` - Hubungi Kami / Get In Touch
- `contactPage.getInTouchDesc` - Description
- `contactPage.name` - Nama Lengkap / Full Name
- `contactPage.email` - Email
- `contactPage.phone` - Nomor Telepon / Phone Number
- `contactPage.company` - Nama Perusahaan / Company Name
- `contactPage.service` - Layanan yang Diminati / Service of Interest
- `contactPage.message` - Pesan Anda / Your Message
- `contactPage.send` - Kirim Pesan / Send Message
- `contactPage.office` - Kantor Kami / Our Office
- `contactPage.businessHours` - Jam Kerja / Business Hours
- `contactPage.monFri` - Senin - Jumat / Monday - Friday
- `contactPage.saturday` - Sabtu / Saturday
- `contactPage.sunday` - Minggu / Sunday
- `contactPage.closed` - Tutup / Closed

### Join Freelance Page
- `joinFreelance.title` - Bergabung dengan Network Wiselab / Join Wiselab Network
- `joinFreelance.subtitle` - Subtitle
- `joinFreelance.why` - Mengapa Bergabung? / Why Join?
- `joinFreelance.flexible.title` - Fleksibilitas / Flexibility
- `joinFreelance.flexible.desc` - Description
- `joinFreelance.projects.title` - Proyek Berkualitas / Quality Projects
- `joinFreelance.projects.desc` - Description
- `joinFreelance.payment.title` - Pembayaran Kompetitif / Competitive Payment
- `joinFreelance.payment.desc` - Description
- `joinFreelance.growth.title` - Pengembangan Karir / Career Growth
- `joinFreelance.growth.desc` - Description
- `joinFreelance.apply` - Daftar Sekarang / Apply Now
- `joinFreelance.fullName` - Nama Lengkap / Full Name
- `joinFreelance.portfolio` - Link Portfolio / Portfolio Link
- `joinFreelance.expertise` - Keahlian Utama / Main Expertise
- `joinFreelance.experience` - Pengalaman (tahun) / Experience (years)
- `joinFreelance.about` - Tentang Anda / About You
- `joinFreelance.submit` - Kirim Lamaran / Submit Application

### Common
- `common.backToProducts` - Kembali ke Produk / Back to Products
- `common.readMore` - Baca Selengkapnya / Read More

## Komponen yang Perlu Diupdate

1. **HeroSection.tsx** - Hero homepage
2. **ServicesSection.tsx** - Services di homepage
3. **PortfolioSection.tsx** - Products di homepage  
4. **WhyUsSection.tsx** - Why us section
5. **Footer.tsx** - Footer
6. **ServicesPage.tsx** - Halaman services
7. **PortfolioPage.tsx** - Halaman products
8. **ContactPage.tsx** - Halaman contact
9. **JoinFreelancePage.tsx** - Halaman join freelance
10. **PortfolioDetail.tsx** - Detail produk

## Contoh Implementasi Lengkap

Lihat `Navbar.tsx` untuk contoh lengkap bagaimana menggunakan translations di dalam komponen.

## Note

- Jangan lupa untuk menambahkan translation key baru ke file `/contexts/LanguageContext.tsx` jika ada text baru yang perlu ditranslate
- Pastikan semua key tersedia dalam kedua bahasa (id dan en)
- Language state akan persist selama session browser
