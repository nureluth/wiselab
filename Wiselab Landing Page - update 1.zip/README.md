
  # Wiselab Landing Page

  This is a code bundle for Wiselab Landing Page. The original project is available at https://www.figma.com/design/oFyUnCV5gJwAsmRVBuJ1ul/Wiselab-Landing-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  